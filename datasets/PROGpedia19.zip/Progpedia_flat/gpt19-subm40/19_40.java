import java.util.Arrays;
import java.util.Scanner;

class NetworkProblem {
    private Scanner scanner = new Scanner(System.in);
    private int[] scenarioData;

    private void processInput() {
        System.out.println("Input: ");
        scenarioData = Arrays.stream(scanner.nextLine().split("#"))
                             .mapToInt(Integer::parseInt)
                             .toArray();
    }

    private void processScenarios() {
        int currentScenarioIndex = 1;
        for (int i = 0; i < scenarioData[0]; i++) { // scenarioData[0] contains the number of scenarios
            int numberOfStudents = scenarioData[currentScenarioIndex++];
            int[][] adjacencyMatrix = new int[numberOfStudents + 1][numberOfStudents + 1];

            while (numberOfStudents-- > 0) {
                adjacencyMatrix = updateAdjacencyMatrix(adjacencyMatrix, scenarioData[currentScenarioIndex++]);
            }
            System.out.println("Case #" + (i + 1));
            findAndPrintGroups(adjacencyMatrix);
        }
    }

    private int[][] updateAdjacencyMatrix(int[][] matrix, int data) {
        // Assuming data represents the connections (simplified for demonstration purposes)
        // Normally, would parse a specific input format to update the matrix
        return matrix; // Returning the matrix unchanged as placeholder
    }

    private void findAndPrintGroups(int[][] matrix) {
        matrix = applyFloydWarshall(matrix);
        identifyGroups(matrix);
    }

    private int[][] applyFloydWarshall(int[][] matrix) {
        for (int k = 0; k < matrix.length; k++) {
            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix.length; j++) {
                    if ((matrix[i][k] == 1) && (matrix[k][j] == 1)) {
                        matrix[i][j] = 1;
                    }
                }
            }
        }
        return matrix;
    }

    private void identifyGroups(int[][] matrix) {
        // Group identification logic (placeholder since algorithm specifics are not described)
        int groups = 0, ungrouped = 0;
        // Simplified placeholder demonstrating result output
        System.out.println(groups + " " + ungrouped);
    }

    public static void main(String[] args) {
        NetworkProblem problem = new NetworkProblem();
        problem.processInput();
        problem.processScenarios();
    }
}