import java.io.IOException;
import java.util.Arrays;

class NetworkAnalyzer {
    private static int scenarioCount = 0;
    private static int studentCount = 0;
    private static int caseNumber = 1;

    public static void main(String[] args) {
        System.out.println("Input: ");
        String inputData = readInput();
        processInput(inputData);
    }

    private static String readInput() {
        StringBuilder inputBuffer = new StringBuilder();
        try {
            int character;
            while ((character = System.in.read()) != -1 && character != '\n') {
                if (character != '\r') {
                    inputBuffer.append((char) character);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return inputBuffer.toString();
    }

    private static void processInput(String inputData) {
        String[] parts = inputData.split("#");
        scenarioCount = Integer.parseInt(parts[0].trim());

        for (int index = 1; index < parts.length && scenarioCount > 0; index++, scenarioCount--) {
            studentCount = Integer.parseInt(parts[index].trim());
            int[][] networkData = new int[studentCount + 1][studentCount + 1];

            for (int i = 0; i < studentCount; i++) {
                networkData = createNetworkArray(parts[++index], networkData);
            }

            System.out.println("Case #" + caseNumber++);
            verifyNetworkConnections(networkData);
        }
    }

    private static int[][] createNetworkArray(String line, int[][] networkData) {
        String[] parts = line.trim().split(" ");
        int student = Integer.parseInt(parts[0]);
        Arrays.fill(networkData[student], 0); // Reset the row for clean slate
        networkData[student][student] = 1; // Self-loop

        for (int j = 2; j < parts.length; j++) {
            networkData[student][Integer.parseInt(parts[j])] = 1;
        }
        return networkData;
    }

    private static void verifyNetworkConnections(int[][] networkData) {
        floydWarshallAlgorithm(networkData);
        identifyGroups(networkData);
    }

    private static void identifyGroups(int[][] networkData) {
        int[][] groups = new int[networkData.length][];
        for (int i = 1; i < networkData.length; i++) {
            for (int j = 1; j < networkData.length; j++) {
                if (i != j && networkData[i][j] == 1 && networkData[j][i] == 1) {
                    groups = mergeGroups(groups, i, j);
                    networkData[j][i] = 0; // Mark as processed
                }
            }
        }
        displayResults(groups);
    }

    private static int[][] mergeGroups(int[][] groups, int i, int j) {
        boolean foundGroup = false;
        for (int[] group : groups) {
            if (group != null && Arrays.binarySearch(group, i) >= 0) {
                group = mergeArrays(group, new int[]{j});
                foundGroup = true;
                break;
            }
        }
        if (!foundGroup) {
            groups = Arrays.copyOf(groups, groups.length + 1);
            groups[groups.length - 1] = new int[]{i, j};
        }
        return groups;
    }

    private static void displayResults(int[][] groups) {
        int groupsCount = 0;
        int isolatedCount = 0;
        for (int[] group : groups) {
            if (group != null) {
                if (group.length > 1) {
                    groupsCount++;
                } else {
                    isolatedCount++;
                }
            }
        }
        System.out.println(groupsCount + " " + isolatedCount);
    }

    private static void floydWarshallAlgorithm(int[][] network) {
        for (int k = 0; k < network.length; k++) {
            for (int i = 0; i < network.length; i++) {
                for (int j = 0; j < network.length; j++) {
                    if (network[i][k] == 1 && network[k][j] == 1) {
                        network[i][j] = 1;
                    }
                }
            }
        }
    }

    private static int[] mergeArrays(int[] a, int[] b) {
        int[] merged = new int[a.length + b.length];
        System.arraycopy(a, 0, merged, 0, a.length);
        System.arraycopy(b, 0, merged, a.length, b.length);
        Arrays.sort(merged);
        return merged;
    }
}