import java.io.*;
import java.util.Scanner;

class MatrixAnalyzer {

    private static void initializeCheckFlags(boolean[] flags, int size) {
        for (int i = 0; i < size; i++)
            flags[i] = false;
    }

    private static void initializeRelationCounts(int[] counts, int size) {
        for (int i = 0; i < size; i++)
            counts[i] = 0;
    }

    private static void countRelations(boolean[][] matrix, int[] counts, int size) {
        for (int row = 0; row < size; row++)
            for (int col = 0; col < size; col++) {
                if (matrix[row][col])
                    counts[row]++;
            }
    }

    private static void printRelationCounts(int[] counts) {
        for (int count : counts)
            System.out.print("[" + count + "]");
        System.out.println();
    }

    private static void establishLinks(boolean[][] matrix, int size) {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (matrix[row][col]) {
                    for (int target = 0; target < size; target++) {
                        if (matrix[col][target]) matrix[row][target] = true;
                        if (matrix[target][row]) matrix[target][col] = true;
                    }
                }
            }
        }
    }

    private static void resetMatrix(boolean[][] matrix, int size) {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++)
                matrix[row][col] = col == row;
        }
    }

    private static void displayMatrix(boolean[][] matrix, int size) {
        System.out.print("|||");
        for (int i = 1; i <= size; i++)
            System.out.print("|" + i + "|");
        System.out.println();
        for (int row = 0; row < size; row++) {
            System.out.print("|" + (row + 1) + "|");
            for (int col = 0; col < size; col++) {
                System.out.print("[" + (matrix[row][col] ? 1 : 0) + "]");
            }
            System.out.println();
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numScenarios = scanner.nextInt();

        for (int scenario = 1; scenario <= numScenarios; scenario++) {
            int dimension = scanner.nextInt();
            boolean[][] matrix = new boolean[dimension][dimension];
            resetMatrix(matrix, dimension);

            for (int i = 0; i < dimension; i++) {
                int index = scanner.nextInt() - 1;
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    matrix[index][scanner.nextInt() - 1] = true;
                }
            }

            establishLinks(matrix, dimension);

            int[] relationCounts = new int[dimension];
            boolean[] checked = new boolean[dimension];
            initializeRelationCounts(relationCounts, dimension);
            initializeCheckFlags(checked, dimension);
            countRelations(matrix, relationCounts, dimension);

            int numGroups = 0;
            int outliers = 0;

            for (int i = 0; i < dimension; i++) {
                if (checked[i]) continue;

                int relationCount = relationCounts[i];
                int numElements = 1;
                for (int j = 0; j < dimension; j++) {
                    if (!checked[j] && i != j && relationCount == relationCounts[j]) {
                        boolean identical = true;
                        for (int k = 0; k < dimension; k++) {
                            if (matrix[i][k] != matrix[j][k]) {
                                identical = false;
                                break;
                            }
                        }
                        if (identical) {
                            checked[i] = checked[j] = true;
                            numElements++;
                        }
                    }
                }
                if (numElements < 4) outliers += numElements;
                else numGroups++;
            }

            System.out.printf("Case #%d\n%d %d\n", scenario, numGroups, outliers);
        }
    }
}