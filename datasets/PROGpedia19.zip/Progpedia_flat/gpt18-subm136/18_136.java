import java.util.*;

class NetworkAnalysis {
    static final int MAX_SIZE = 1000;
    List<List<Integer>> edges = new ArrayList<>(MAX_SIZE);
    int[] state, predecessor, discoveryTime, closingTime;
    int timestamp;

    NetworkAnalysis() {
        for (int i = 0; i < MAX_SIZE; i++) {
            edges.add(new LinkedList<>());
        }
        state = new int[MAX_SIZE];
        predecessor = new int[MAX_SIZE];
        discoveryTime = new int[MAX_SIZE];
        closingTime = new int[MAX_SIZE];
    }

    NetworkAnalysis reverseGraph() {
        NetworkAnalysis reversed = new NetworkAnalysis();
        for (int i = 0; i < edges.size(); i++) {
            for (Integer node : edges.get(i)) {
                reversed.edges.get(node).add(i);
            }
        }
        return reversed;
    }

    void DFS(List<Integer> startNodes, List<Integer> orderList) {
        Arrays.fill(state, 0);
        Arrays.fill(predecessor, -1);
        Arrays.fill(discoveryTime, -1);
        Arrays.fill(closingTime, -1);
        timestamp = 0;
        for (Integer node : startNodes) {
            if (state[node] == 0) explore(node, orderList);
        }
    }

    void explore(int node, List<Integer> orderList) {
        state[node] = 1;
        discoveryTime[node] = ++timestamp;
        for (Integer adjacent : edges.get(node)) {
            if (state[adjacent] == 0) {
                predecessor[adjacent] = node;
                explore(adjacent, orderList);
            }
        }
        state[node] = 2;
        closingTime[node] = ++timestamp;
        orderList.add(0, node);
    }

    PriorityQueue<Integer> findNodesWithValue(int targetValue) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();
        for (int i = 0; i < predecessor.length; i++) {
            if (predecessor[i] == targetValue) queue.add(i);
        }
        return queue;
    }

    void constructForest(List<Integer> tree, int rootValue) {
        tree.add(rootValue);
        PriorityQueue<Integer> children = findNodesWithValue(rootValue);
        while (!children.isEmpty()) {
            constructForest(tree, children.poll());
        }
    }

    List<List<Integer>> generateForest() {
        List<List<Integer>> forest = new ArrayList<>(MAX_SIZE);
        for (int i = 0; i < edges.size(); i++) {
            if (predecessor[i] == -1) {
                List<Integer> tree = new LinkedList<>();
                constructForest(tree, i);
                forest.add(tree);
            }
        }
        forest.removeIf(Objects::isNull);
        return forest;
    }
}

class SociologyCaseStudy {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();
        for (int scenarioIndex = 0; scenarioIndex < scenarios; scenarioIndex++) {
            NetworkAnalysis graph = new NetworkAnalysis();
            List<Integer> initialNodes = new LinkedList<>();
            List<Integer> finishingNodes = new LinkedList<>();
            
            int students = scanner.nextInt();
            for (int student = 0; student < students; student++) {
                initialNodes.add(student);
            }
            for (int student = 0; student < students; student++) {
                int studentId = scanner.nextInt();
                int friendsCount = scanner.nextInt();
                for (int friend = 0; friend < friendsCount; friend++) {
                    graph.edges.get(studentId - 1).add(scanner.nextInt() - 1);
                }
            }

            graph.DFS(initialNodes, finishingNodes);
            NetworkAnalysis transposedGraph = graph.reverseGraph();
            List<Integer> newStartNodes = new LinkedList<>();
            transposedGraph.DFS(finishingNodes, newStartNodes);
            
            List<List<Integer>> groups = transposedGraph.generateForest();
            int count = 0, largeGroups = 0, isolatedStudents = 0;
            System.out.printf("Case #%d\n", scenarioIndex + 1);
            for (List<Integer> group : groups) {
                if (group.size() >= 4)
                    largeGroups++;
                else
                    isolatedStudents += group.size();
            }
            System.out.printf("%d %d\n", largeGroups, isolatedStudents);
        }
        scanner.close();
    }
}