import java.util.*;

class GraphProcessor {
    private Scanner scanner;
    private int graphSize;
    private int componentSize;
    private boolean[] marked;
    private LinkedList<Integer> traversalOrder = new LinkedList<>();
    private ArrayList<LinkedList<Integer>> graph = new ArrayList<>();
    private ArrayList<LinkedList<Integer>> reverseGraph = new ArrayList<>();
    private HashMap<Integer, Integer> nodeIndexMap = new HashMap<>();

    GraphProcessor(Scanner scannerInput) {
        this.scanner = scannerInput;
    }

    private int getNodeIndex(int node) {
        return nodeIndexMap.computeIfAbsent(node, k -> {
            graph.add(new LinkedList<>());
            reverseGraph.add(new LinkedList<>());
            return nodeIndexMap.size();
        });
    }

    void loadData() {
        graphSize = scanner.nextInt();
        nodeIndexMap.clear();
        graph.clear();
        reverseGraph.clear();
        for (int i = 0; i < graphSize; i++) {
            int node = getNodeIndex(scanner.nextInt());
            int edges = scanner.nextInt();
            for (int j = 0; j < edges; j++) {
                int connectedNode = getNodeIndex(scanner.nextInt());
                graph.get(node).add(connectedNode);
                reverseGraph.get(connectedNode).add(node);
            }
        }
        graphSize = nodeIndexMap.size();
    }

    private void depthFirstSearch(int node) {
        if (marked[node]) return;
        marked[node] = true;
        for (int next : graph.get(node)) {
            if (!marked[next]) depthFirstSearch(next);
        }
        traversalOrder.addFirst(node);
    }

    private void exploreComponent(int node) {
        componentSize++;
        marked[node] = true;
        for (int next : reverseGraph.get(node)) {
            if (!marked[next]) exploreComponent(next);
        }
    }

    void analyzeGraph() {
        traversalOrder.clear();
        marked = new boolean[graphSize];
        Arrays.fill(marked, false);
        for (int i = 0; i < graphSize; i++) depthFirstSearch(i);
        Arrays.fill(marked, false);
        int largeComponents = 0, smallComponentNodes = 0;
        for (int node : traversalOrder) {
            if (!marked[node]) {
                componentSize = 0;
                exploreComponent(node);
                if (componentSize >= 4) largeComponents++;
                else smallComponentNodes += componentSize;
            }
        }
        System.out.printf("%d %d\n", largeComponents, smallComponentNodes);
    }
}

class GraphAnalysis {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GraphProcessor processor = new GraphProcessor(scanner);
        int testCases = scanner.nextInt();
        for (int testCase = 1; testCase <= testCases; testCase++) {
            System.out.printf("Case#%d\n", testCase);
            processor.loadData();
            processor.analyzeGraph();
        }
    }
}