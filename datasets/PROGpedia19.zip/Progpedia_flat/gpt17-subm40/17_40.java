import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

class RefactoredSolution {

    private static int scenarioCount = 0;
    private static int studentCount = 0;
    private static int caseNum = 1;

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Input: ");
        String[] inputLines = reader.readLine().split("#");

        scenarioCount = Integer.parseInt(inputLines[0].trim());
        int idx = 1;

        while (scenarioCount-- > 0) {
            studentCount = Integer.parseInt(inputLines[idx++].trim());
            int[][] connections = new int[studentCount + 1][studentCount + 1];

            for (int student = 0; student < studentCount; student++) {
                buildConnections(inputLines[idx++], connections);
            }

            System.out.println("Case #" + caseNum);
            analyzeConnections(connections);
            caseNum++;
        }
    }

    private static void buildConnections(String input, int[][] connections) {
        String[] parts = input.split(" ");
        int src = Integer.parseInt(parts[0].trim());

        for (int j = 2; j < parts.length; j++) {
            int dest = Integer.parseInt(parts[j].trim());
            connections[src][dest] = 1;
        }
        connections[src][src] = 1;
    }

    private static void analyzeConnections(int[][] connections) {
        applyFloydWarshall(connections);
        List<List<Integer>> groups = findGroups(connections);
        printGroups(groups);
    }

    private static void applyFloydWarshall(int[][] connections) {
        int n = connections.length;
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (connections[i][k] + connections[k][j] == 2) {
                        connections[i][j] = 1;
                    }
                }
            }
        }
    }

    private static List<List<Integer>> findGroups(int[][] connections) {
        List<List<Integer>> groups = new ArrayList<>();

        for (int i = 1; i < connections.length; i++) {
            boolean foundGroup = false;
            for (List<Integer> group : groups) {
                if (group.contains(i)) {
                    foundGroup = true;
                    break;
                }
            }
            if (!foundGroup) {
                List<Integer> newGroup = new ArrayList<>();
                newGroup.add(i);
                for (int j = 1; j < connections.length; j++) {
                    if (connections[i][j] == 1 && connections[j][i] == 1) {
                        newGroup.add(j);
                    }
                }
                groups.add(newGroup);
            }
        }

        return groups;
    }

    private static void printGroups(List<List<Integer>> groups) {
        int connectionCount = 0;
        int isolatedCount = 0;

        for (List<Integer> group : groups) {
            if (group.size() > 1) {
                connectionCount++;
            } else {
                isolatedCount++;
            }
        }

        System.out.println(connectionCount + " " + isolatedCount);
    }
}