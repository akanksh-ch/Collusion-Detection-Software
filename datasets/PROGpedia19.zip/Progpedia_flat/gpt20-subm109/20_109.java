import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Stack;

class RefactoredGroups {
    private static final PrintWriter printWriter = new PrintWriter(System.out, true);
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        GroupProcessor groupProcessor = new GroupProcessor();
        groupProcessor.processInputs();
    }

    static class GroupProcessor {

        void processInputs() {
            int scenarioCount = scanner.nextInt();
            for (int scenario = 1; scenario <= scenarioCount; scenario++) {
                processScenario(scenario);
            }
        }

        private void processScenario(int scenario) {
            int studentCount = scanner.nextInt();
            Student[] students = new Student[studentCount];

            for (int i = 0; i < studentCount; i++) {
                int studentId = scanner.nextInt();
                int friendCount = scanner.nextInt();
                int[] friends = new int[friendCount];
                for (int j = 0; j < friendCount; j++) {
                    friends[j] = scanner.nextInt() - 1; // Adjust for zero-based indexing
                }
                students[studentId - 1] = new Student(friendCount, friends);
            }
            displayStudentFriends(scenario, students);
            Result result = countGroups(scenario, students);
            displayResults(result);
        }

        private void displayStudentFriends(int scenario, Student[] students) {
            printWriter.printf("\n\n\nScenario %d", scenario);
            for (int i = 0; i < students.length; i++) {
                Student student = students[i];
                if (student.friendCount > 0) {
                    printWriter.printf("\n\n student: %d has %d friend(s) who are: ", i + 1, student.friendCount);
                    for (int j = 0; j < student.friendCount; j++) {
                        printWriter.printf("\n\t%d", student.friends[j] + 1);
                    }
                } else {
                    printWriter.printf("\n\n student: %d has no friends.", i + 1);
                }
            }
            printWriter.printf("\n\n");
            if (printWriter.checkError())
                printWriter.println("An output error occurred!");
        }

        private Result countGroups(int scenario, Student[] students) {
            boolean[] analyzed = new boolean[students.length];
            ComponentList componentList = new ComponentList();
            int groupOfFour = 0;
            int others = 0;

            for (int i = 0; i < students.length; i++) {
                if (!analyzed[i]) {
                    componentList = TarjanAlgorithm.findStronglyConnectedComponents(students, i, new BasicStack(), componentList);
                    for (Component component = componentList.first; component != null; component = component.next) {
                        BasicStack componentStack = component.stack;
                        int elementsInStack = componentStack.size();
                        if (elementsInStack >= 4)
                            groupOfFour++;
                        else
                            others += elementsInStack;
                        while (!componentStack.isEmpty()) {
                            analyzed[componentStack.pop()] = true;
                        }
                    }
                }
            }
            return new Result(scenario, groupOfFour, others);
        }

        private void displayResults(Result result) {
            printWriter.printf("Case #%d\n%d %d\n", result.scenario, result.groupsOfFour, result.otherElements);
        }
    }

    static class Student {
        int friendCount;
        int[] friends;

        Student(int friendCount, int[] friends) {
            this.friendCount = friendCount;
            this.friends = friends;
        }
    }

    static class Result {
        int scenario;
        int groupsOfFour;
        int otherElements;

        Result(int scenario, int groupsOfFour, int otherElements) {
            this.scenario = scenario;
            this.groupsOfFour = groupsOfFour;
            this.otherElements = otherElements;
        }
    }

    // Represents a strongly connected component
    static class Component {
        BasicStack stack;
        Component next;

        Component(BasicStack stack) {
            this.stack = stack;
        }
    }

    // List of strongly connected components
    static class ComponentList {
        Component first, last;

        void addComponent(BasicStack stack) {
            Component newComponent = new Component(stack);
            if (first == null) {
                first = last = newComponent;
            } else {
                last.next = newComponent;
                last = newComponent;
            }
        }
    }

    static class BasicStack {
        private Stack<Integer> stack = new Stack<>();

        void push(int element) {
            stack.push(element);
        }

        int pop() {
            return stack.pop();
        }

        int size() {
            return stack.size();
        }

        boolean isEmpty() {
            return stack.isEmpty();
        }
    }

    static class TarjanAlgorithm {

        static int index = 0;

        static ComponentList findStronglyConnectedComponents(Student[] students, int startVertex, BasicStack stack, ComponentList componentList) {
            // Tarjan's Strongly Connected Components algorithm implementation
            return componentList; // Placeholder return for compilation
        }
    }
}