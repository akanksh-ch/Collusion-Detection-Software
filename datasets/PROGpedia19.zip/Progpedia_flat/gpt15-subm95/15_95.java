import java.io.*;
import java.util.Scanner;

class Main {

    private static void initializeMatrix(boolean[][] matrix, int dimension) {
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < i; j++) {
                matrix[i][j] = false;
            }
            matrix[i][i] = true; // Diagonal elements are true.
            for (int j = i + 1; j < dimension; j++) {
                matrix[i][j] = false;
            }
        }
    }

    private static void updateMatrixRelations(Scanner scanner, boolean[][] matrix, int dimension) {
        for (int i = 0; i < dimension; i++) {
            int index = scanner.nextInt() - 1;
            int relations = scanner.nextInt();
            for (int j = 0; j < relations; j++) {
                matrix[index][scanner.nextInt() - 1] = true;
            }
        }
    }

    private static void propagateLinks(boolean[][] matrix, int dimension) {
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (matrix[i][j]) {
                    for (int k = 0; k < dimension; k++) {
                        if (matrix[j][k]) matrix[i][k] = true;
                        if (matrix[k][i]) matrix[k][j] = true;
                    }
                }
            }
        }
    }

    private static int[] calculateRelationCounts(boolean[][] matrix, int dimension) {
        int[] relationCounts = new int[dimension];
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (matrix[i][j]) relationCounts[i]++;
            }
        }
        return relationCounts;
    }

    private static void analyzeAndDisplayResults(int[] relationCounts, boolean[][] matrix, int dimension, int situationNumber) {
        boolean[] checked = new boolean[dimension];
        int groups = 0;
        int outliers = 0;

        for (int i = 0; i < dimension; i++) {
            if (checked[i]) continue;

            int count = relationCounts[i];
            int elements = 1;
            for (int j = 0; j < dimension; j++) {
                if (!checked[j] && i != j && relationCounts[j] == count &&
                        areMatricesEqual(matrix[i], matrix[j], dimension)) {
                    checked[i] = checked[j] = true;
                    elements++;
                }
            }

            if (elements < 4) outliers += elements;
            else groups++;
        }

        System.out.println("Caso #" + situationNumber + "\n" + groups + " " + outliers);
    }

    private static boolean areMatricesEqual(boolean[] matrix1, boolean[] matrix2, int dimension) {
        for (int i = 0; i < dimension; i++) {
            if (matrix1[i] != matrix2[i]) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int numSituations = scanner.nextInt();
            for (int s = 1; s <= numSituations; s++) {
                int dimension = scanner.nextInt();
                boolean[][] matrix = new boolean[dimension][dimension];

                initializeMatrix(matrix, dimension);
                updateMatrixRelations(scanner, matrix, dimension);
                propagateLinks(matrix, dimension);

                int[] relationCounts = calculateRelationCounts(matrix, dimension);
                analyzeAndDisplayResults(relationCounts, matrix, dimension, s);
            }
        }
    }
}