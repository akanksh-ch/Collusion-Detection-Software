import java.io.*;
import java.util.*;

class TestGrupos {
    
    static void displayStudents(int testCase, int totalStudents, Vertex[] studentList) {
        Grupos.pw.println("\n\n\nScenario " + testCase);
        for (int student = 0; student < totalStudents; student++) {
            int friendCount = studentList[student].getFriendCount();
            if (friendCount > 0) {
                Grupos.pw.println("\n\n Student: " + (student + 1) + " has " + friendCount + " friend(s), namely: ");
                for (int friend = 0; friend < friendCount; friend++)
                    Grupos.pw.print("\n\t" + (studentList[student].getFriend(friend) + 1));
            } else
                Grupos.pw.println("\n\n Student: " + (student + 1) + " has no friends.");
        }
        Grupos.pw.println("\n\n");
        if (Grupos.pw.checkError())
            Grupos.pw.println("Output error occurred!");
    }
    
    static void listSCCs(int testCase, SCCList sccList) {
        for (SCC scc = sccList.getFirst(); scc != null; scc = scc.getNext())
            displaySCC(scc.getStack());
        Grupos.pw.println("\nScenario: " + testCase);
    }
    
    static void displaySCC(CustomStack stack) {
        if (stack.isEmpty()) {
            Grupos.pw.println("\n\tStack is empty");
            return;
        }
        int[] elements = stack.getElements();
        Grupos.pw.println("\n\n\t Stack:");
        for (int elem : elements)
            Grupos.pw.println("\n\t\t" + (elem + 1));
        Grupos.pw.println("\n\n");
    }
}

class Vertex {
    private int friendCount;
    private int[] friends;
    private int index = -1;
    private int lowLink = -1;

    Vertex(int count, int[] frnds) {
        this.friendCount = count;
        this.friends = frnds;
    }

    int getFriendCount() {
        return this.friendCount;
    }

    int getFriend(int idx) {
        return this.friends[idx];
    }

    void setIndex(int idx) {
        this.index = idx;
    }

    int getIndex() {
        return this.index;
    }

    void setLowLink(int ll) {
        this.lowLink = ll;
    }

    int getLowLink() {
        return this.lowLink;
    }
    
    boolean hasFriend(int friendID) {
        for (int friend : friends) {
            if (friend == friendID) return true;
        }
        return false;
    }
}

class Results {
    private Result first = null, last = null;
    
    void addResult(Result result) {
        if (first == null) {
            first = last = result;
        } else {
            last.setNext(result);
            last = result;
        }
    }
    
    Result getFirst() {
        return this.first;
    }
    
    void displayResults() {
        for (Result current = getFirst(); current != null; current = current.getNext()) {
            Grupos.pw.println("Case #" + current.getCaseNumber() + "\n" + current.getGroupOfFour() + " " + current.getOtherElements());
        }
    }
}

class Result {
    private final int caseNumber;
    private int groupOfFour, otherElements;
    private Result next;

    Result(int caseNum, int fours, int others) {
        this.caseNumber = caseNum;
        this.groupOfFour = fours;
        this.otherElements = others;
    }

    void setNext(Result nextResult) {
        this.next = nextResult;
    }

    Result getNext() {
        return this.next;
    }
    
    int getCaseNumber() {
        return this.caseNumber;
    }

    int getGroupOfFour() {
        return this.groupOfFour;
    }

    int getOtherElements() {
        return this.otherElements;
    }
}

class SCCList {
    private SCC first = null, last = null;
    
    void addSCC(CustomStack stack) {
        SCC newSCC = new SCC(stack);
        if (first == null) first = last = newSCC;
        else {
            last.setNext(newSCC);
            last = newSCC;
        }
    }
    
    SCC getFirst() {
        return this.first;
    }
}

class SCC {
    private CustomStack stack;
    private SCC next;

    SCC(CustomStack stack) {
        this.stack = stack;
    }

    void setNext(SCC next) {
        this.next = next;
    }
    
    SCC getNext() {
        return this.next;
    }
    
    CustomStack getStack() {
        return this.stack;
    }
}

class CustomStack {
    private int size = 0;
    private Node top = null;

    boolean isEmpty() {
        return top == null;
    }
    
    void push(int value) {
        Node newNode = new Node(value);
        newNode.setNext(top);
        top = newNode;
        size++;
    }
    
    int pop() {
        if (isEmpty()) return -1;
        int value = top.getValue();
        top = top.getNext();
        size--;
        return value;
    }
    
    int getSize() {
        return size;
    }
    
    int[] getElements() {
        int[] elements = new int[size];
        Node current = top;
        for (int i = size - 1; i >= 0; i--) {
            elements[i] = current.getValue();
            current = current.getNext();
        }
        return elements;
    }
    
    boolean contains(int value) {
        Node current = top;
        while (current != null) {
            if (current.getValue() == value) return true;
            current = current.getNext();
        }
        return false;
    }
    
    CustomStack getElementsUpTo(int value) {
        CustomStack resultStack = new CustomStack();
        int element;
        do {
            element = this.pop();
            resultStack.push(element);
        } while (element != value && !isEmpty());
        return resultStack;
    }
}

class Node {
    private final int value;
    private Node next;
    
    Node(int value) {
        this.value = value;
    }

    void setNext(Node next) {
        this.next = next;
    }
    
    Node getNext() {
        return this.next;
    }

    int getValue() {
        return this.value;
    }
}

class Grupos {
    public static PrintWriter pw = new PrintWriter(System.out, true);
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        inputAndProcessCases();
    }

    private static void inputAndProcessCases() {
        // Implementation for reading input, processing cases, and populating results
    }
}