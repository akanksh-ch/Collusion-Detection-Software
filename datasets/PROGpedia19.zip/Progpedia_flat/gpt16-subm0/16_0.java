import java.util.*;

class SolutionProcessor {
    private Scanner scanner;
    private int nodeCount;
    private int componentNodeCount;
    private boolean[] visited;
    private Deque<Integer> finishOrder = new LinkedList<>();
    private HashMap<Integer, Integer> nodeIndexMap = new HashMap<>();
    private ArrayList<LinkedList<Integer>> adjList = new ArrayList<>();
    private ArrayList<LinkedList<Integer>> transposedAdjList = new ArrayList<>();

    public SolutionProcessor(Scanner scanner) {
        this.scanner = scanner;
    }

    private int getOrCreateNodeIndex(int node) {
        return nodeIndexMap.computeIfAbsent(node, k -> {
            adjList.add(new LinkedList<>());
            transposedAdjList.add(new LinkedList<>());
            return nodeIndexMap.size();
        });
    }

    public void readGraph() {
        nodeCount = scanner.nextInt();
        nodeIndexMap.clear();
        adjList.clear();
        transposedAdjList.clear();
        
        for (int i = 0; i < nodeCount; i++) {
            int node = getOrCreateNodeIndex(scanner.nextInt());
            int edgeCount = scanner.nextInt();
            
            for (int j = 0; j < edgeCount; j++) {
                int destinationNode = getOrCreateNodeIndex(scanner.nextInt());
                adjList.get(node).add(destinationNode);
                transposedAdjList.get(destinationNode).add(node);
            }
        }
        nodeCount = nodeIndexMap.size();
    }

    private void depthFirstSearch(int node) {
        if (visited[node]) return;
        
        visited[node] = true;
        for (int neighbour : adjList.get(node)) {
            if (!visited[neighbour]) {
                depthFirstSearch(neighbour);
            }
        }
        finishOrder.addFirst(node);
    }

    private void floodFill(int node) {
        componentNodeCount++;
        visited[node] = true;
        for (int neighbour : transposedAdjList.get(node)) {
            if (!visited[neighbour]) {
                floodFill(neighbour);
            }
        }
    }

    public void solveAndPrint() {
        finishOrder.clear();
        visited = new boolean[nodeCount];
        Arrays.fill(visited, false);

        for (int i = 0; i < nodeCount; i++) {
            depthFirstSearch(i);
        }

        Arrays.fill(visited, false);
        int groupsOfSize4OrMore = 0, otherNodesCount = 0;

        for (int node : finishOrder) {
            if (!visited[node]) {
                componentNodeCount = 0;
                floodFill(node);
                if (componentNodeCount >= 4) {
                    groupsOfSize4OrMore++;
                } else {
                    otherNodesCount += componentNodeCount;
                }
            }
        }
        System.out.printf("%d %d\n", groupsOfSize4OrMore, otherNodesCount);
    }
}

class ProblemSolverApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SolutionProcessor processor = new SolutionProcessor(scanner);
        int cases = scanner.nextInt();
        
        for (int i = 1; i <= cases; i++) {
            System.out.printf("Case#%d\n", i);
            processor.readGraph();
            processor.solveAndPrint();
        }
        scanner.close();
    }
}