import java.io.IOException;
import java.util.Arrays;

class ScenarioAnalyzer {

    private static int scenarioCount = 0;
    private static int studentCount = 0;
    private static int currentScenario = 1;
    private static String inputData = "";

    public static void main(String[] args) {
        System.out.println("Input: ");
        inputData = gatherInput();
        processInput(inputData);
    }

    private static String gatherInput() {
        StringBuilder result = new StringBuilder();
        int charCode;
        do {
            charCode = readCharacter();
            if (charCode > 0)
                result.append((char) charCode);
        } while (charCode >= 0);
        return result.toString();
    }
    
    private static int readCharacter() {
        try {
            int charInt = System.in.read();
            if (charInt == '\n' || charInt < 0) return -1;
            return charInt == '\r' ? -2 : charInt;
        } catch (IOException e) {
            return -1;
        }
    }

    private static void processInput(String input) {
        String[] records = input.split("#");
        analyzeScenarios(records);
    }

    private static void analyzeScenarios(String[] records) {
        scenarioCount = Integer.parseInt(records[0].trim());

        for (int index = 1; index < records.length && scenarioCount > 0; index++, scenarioCount--) {
            studentCount = Integer.parseInt(records[index].trim());
            int[][] studentRelations = new int[studentCount + 1][studentCount + 1];
            for (int student = 0; student < studentCount; student++) {
                index++;
                studentRelations = buildRelationsMatrix(records[index], studentRelations);
            }
            
            System.out.println("Caso #" + currentScenario);
            evaluateAndPrintGroups(studentRelations);
            currentScenario++;
        }
    }

    private static int[][] buildRelationsMatrix(String record, int[][] relationsMatrix) {
        String[] connections = record.split(" ");
        int studentIndex = Integer.parseInt(connections[0].trim());
        for (int i = 2; i < connections.length; i++) {
            int connectedStudent = Integer.parseInt(connections[i].trim());
            relationsMatrix[studentIndex][connectedStudent] = 1;
        }
        relationsMatrix[studentIndex][studentIndex] = 1;
        return relationsMatrix;
    }

    private static void evaluateAndPrintGroups(int[][] relationsMatrix) {
        relationsMatrix = applyFloydWarshall(relationsMatrix);
        searchAndPrintGroups(relationsMatrix);
    }

    private static int[][] applyFloydWarshall(int[][] matrix) {
        int size = matrix.length;
        for (int k = 0; k < size; k++)
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                    if (matrix[i][k] == 1 && matrix[k][j] == 1)
                        matrix[i][j] = 1;
        return matrix;
    }

    private static void searchAndPrintGroups(int[][] matrix) {
        int groups = 0;
        int isolatedCount = 0;
        for (int[] row : matrix) {
            if (row == null || row.length < 1) continue;
            if (isGroup(row)) {
                groups++;
            } else {
                int connections = countConnections(row);
                if (connections <= 1) {
                    isolatedCount += connections;
                } else {
                    isolatedCount += row.length;
                }
            }
        }
        System.out.print(groups + " " + isolatedCount + "\n");
    }

    private static boolean isGroup(int[] row) {
        return Arrays.stream(row).filter(i -> i != 0).count() >= 4;
    }

    private static int countConnections(int[] row) {
        return (int) Arrays.stream(row).filter(i -> i != 0).count();
    }
}