import java.util.*;

class GraphProcessor {
    private Scanner scanner;
    private int totalNodes;
    private boolean[] visited;
    private Deque<Integer> traversalOrder = new LinkedList<>();
    private Map<Integer, Integer> nodeMapping = new HashMap<>();
    private List<List<Integer>> adjacencyList = new ArrayList<>();
    private List<List<Integer>> reverseAdjacencyList = new ArrayList<>();

    GraphProcessor(Scanner scanner) {
        this.scanner = scanner;
    }

    private int findOrCreateNode(int originalNode) {
        if (!nodeMapping.containsKey(originalNode)) {
            int newIndex = nodeMapping.size();
            nodeMapping.put(originalNode, newIndex);
            adjacencyList.add(new LinkedList<>());
            reverseAdjacencyList.add(new LinkedList<>());
        }
        return nodeMapping.get(originalNode);
    }

    public void readGraph() {
        totalNodes = scanner.nextInt();
        nodeMapping.clear();
        adjacencyList.clear();
        reverseAdjacencyList.clear();

        for (int i = 0; i < totalNodes; i++) {
            int node = findOrCreateNode(scanner.nextInt());
            int connections = scanner.nextInt();
            for (int j = 0; j < connections; j++) {
                int targetNode = findOrCreateNode(scanner.nextInt());
                adjacencyList.get(node).add(targetNode);
                reverseAdjacencyList.get(targetNode).add(node);
            }
        }
        totalNodes = nodeMapping.size();
    }

    private void performDepthFirstSearch(int node, boolean reverse) {
        if (visited[node]) return;
        visited[node] = true;
        List<Integer> neighbours = reverse ? reverseAdjacencyList.get(node) : adjacencyList.get(node);
        for (int nextNode : neighbours) {
            if (!visited[nextNode]) performDepthFirstSearch(nextNode, reverse);
        }
        if (!reverse) traversalOrder.addFirst(node);
    }

    private int performFloodFill(int node) {
        int count = 1; // Node itself
        visited[node] = true;
        for (int adjNode : reverseAdjacencyList.get(node)) {
            if (!visited[adjNode]) count += performFloodFill(adjNode);
        }
        return count;
    }

    public void processGraph() {
        traversalOrder.clear();
        visited = new boolean[totalNodes];
        for (int i = 0; i < totalNodes; i++) {
            performDepthFirstSearch(i, false);
        }

        Arrays.fill(visited, false);
        int largeGroups = 0, smallGroupsSum = 0;
        for (int node : traversalOrder) {
            if (!visited[node]) {
                int groupSize = performFloodFill(node);
                if (groupSize >= 4) largeGroups++;
                else smallGroupsSum += groupSize;
            }
        }
        System.out.printf("%d %d\n", largeGroups, smallGroupsSum);
    }
}

class ProblemSolver {
    public static void main(String[] args) {
        Scanner inputScanner = new Scanner(System.in);
        GraphProcessor graphProcessor = new GraphProcessor(inputScanner);
        int testCases = inputScanner.nextInt();

        for (int i = 1; i <= testCases; i++) {
            System.out.printf("Case #%d\n", i);
            graphProcessor.readGraph();
            graphProcessor.processGraph();
        }
    }
}