import java.io.*;
import java.util.Scanner;

class MatrixManipulator {
    private boolean[][] matrix;
    private int matrixDim;

    public MatrixManipulator(int matrixDim) {
        this.matrixDim = matrixDim;
        this.matrix = new boolean[matrixDim][matrixDim];
        initializeMatrix();
    }

    private void initializeMatrix() {
        for (int i = 0; i < this.matrixDim; i++) {
            for (int j = 0; j <= i; j++) {
                if (i == j) {
                    this.matrix[i][j] = true;
                } else {
                    this.matrix[i][j] = this.matrix[j][i] = false;
                }
            }
        }
    }

    public void addRelation(int source, int target) {
        this.matrix[source][target] = true;
    }

    public void enhanceRelations() {
        for (int i = 0; i < this.matrixDim; i++) {
            for (int j = 0; j < this.matrixDim; j++) {
                if (this.matrix[i][j]) {
                    propagateRelation(i, j);
                }
            }
        }
    }

    private void propagateRelation(int src, int dest) {
        for (int k = 0; k < this.matrixDim; k++) {
            this.matrix[src][k] |= this.matrix[dest][k];
            this.matrix[k][dest] |= this.matrix[k][src];
        }
    }

    public int computeRelationCounts() {
        int[] relationCount = new int[this.matrixDim];
        for (int i = 0; i < this.matrixDim; i++) {
            for (int j = 0; j < this.matrixDim; j++) {
                if (this.matrix[i][j]) {
                    relationCount[i]++;
                }
            }
        }
        return analyseRelations(relationCount);
    }

    private int analyseRelations(int[] relationCount) {
        boolean[] visited = new boolean[this.matrixDim];
        int groups = 0;
        int outliers = 0;

        for (int i = 0; i < this.matrixDim; i++) {
            if (!visited[i]) {
                int count = 1;
                visited[i] = true;

                for (int j = i + 1; j < this.matrixDim; j++) {
                    if (!visited[j] && relationCount[i] == relationCount[j] && areRelationsEqual(i, j)) {
                        visited[j] = true;
                        count++;
                    }
                }

                if (count < 4) {
                    outliers += count;
                } else {
                    groups++;
                }
            }
        }
        
        return groups;
    }

    private boolean areRelationsEqual(int rowA, int rowB) {
        for (int k = 0; k < this.matrixDim; k++) {
            if (this.matrix[rowA][k] != this.matrix[rowB][k]) return false;
        }
        return true;
    }
}

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();
        for (int s = 1; s <= scenarios; s++) {
            int matrixDimension = scanner.nextInt();
            MatrixManipulator manipulator = new MatrixManipulator(matrixDimension);

            for (int i = 0; i < matrixDimension; i++) {
                int index = scanner.nextInt() - 1;
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    int target = scanner.nextInt() - 1;
                    manipulator.addRelation(index, target);
                }
            }

            manipulator.enhanceRelations();
            int groups = manipulator.computeRelationCounts();
            System.out.println("Case #" + s + ": " + groups);
        }
    }
}