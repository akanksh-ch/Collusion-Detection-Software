import java.io.*;
import java.util.*;

class ScenarioHandler {
    static void displayStudents(int scenario, int totalStudents, StudentNode[] studentList) {
        GrpManager.grpWriter.print("\n\n\nScenario " + scenario);
        for (int s = 0; s < totalStudents; s++) {
            int friendsCount = studentList[s].getFriendsCount();
            if (friendsCount > 0) {
                GrpManager.grpWriter.print("\n\n student: " + (s + 1) + " has " + friendsCount + " friend(s): ");
                for (int f = 0; f < friendsCount; f++)
                    GrpManager.grpWriter.print("\n\t" + (studentList[s].getFriend(f) + 1));
            } else
                GrpManager.grpWriter.print("\n\n student: " + (s + 1) + " has no friends.");
        }
        GrpManager.grpWriter.print("\n\n");
        if (GrpManager.grpWriter.checkError())
            GrpManager.grpWriter.println("Write error occurred!");
    }
    static void listStronglyConnectedComponents(int stage, SCCList sccList) {
        SCCNode node;
        GrpManager.grpWriter.print("\n\n\nScenario: " + stage);
        for (node = sccList.getFirst(); node != null; node = node.getNext())
            displayGroup(node.getGroup());
    }
    static void displayGroup(GroupStack group) {
        int[] elements;
        int size = group.stackSize(), idx;
        elements = group.getElements();
        GrpManager.grpWriter.print("\n\n\t GroupStack:");
        if (size > 0)
            for (idx = 0; idx < size; idx++)
                GrpManager.grpWriter.print("\n\t\t" + (elements[idx] + 1));
        else
            GrpManager.grpWriter.println("\n\tEmpty");
        GrpManager.grpWriter.print("\n\n");
    }
}

class StudentNode {
    private int friendsCount;
    int[] friends;
    int id, marker;
    StudentNode(int count, int[] frnds) {
        friendsCount = count;
        friends = frnds;
        id = -1;
        marker = -1;
    }
    int getFriendsCount() {
        return friendsCount;
    }
    int getFriend(int index) {
        return friends[index];
    }
    void setId(int idx) {
        id = idx;
    }
    int getId() {
        return id;
    }
    void setMarker(int mark) {
        marker = mark;
    }
    int getMarker() {
        return marker;
    }
}

class GroupsOutcome {
    ScenarioResult first, last;
    GroupsOutcome() {
        first = null;
        last = null;
    }
    void addResult(ScenarioResult rslt) {
        if (first == null) {
            first = rslt;
            last = rslt;
        } else {
            last.setNext(rslt);
            last = rslt;
        }
    }
    ScenarioResult getFirst() {
        return first;
    }
}

class ScenarioResult {
    int scenarioNumber, groupOfFour, others;
    ScenarioResult next;
    ScenarioResult(int scenNum, int groups, int othersCount) {
        scenarioNumber = scenNum;
        groupOfFour = groups;
        others = othersCount;
        next = null;
    }
    void setNext(ScenarioResult nxt) {
        next = nxt;
    }
    ScenarioResult getNext() {
        return next;
    }
}

class SCCList {
    SCCNode first, last;
    SCCList() {
        first = null;
        last = null;
    }
    void addSCC(GroupStack group) {
        SCCNode newNode = new SCCNode(group);
        if (first == null) first = newNode;
        else last.setNext(newNode);
        last = newNode;
    }
    SCCNode getFirst() {
        return first;
    }
}

class SCCNode {
    GroupStack group;
    SCCNode next;
    SCCNode(GroupStack grp) {
        group = grp;
        next = null;
    }
    GroupStack getGroup() {
        return group;
    }
    void setNext(SCCNode nxt) {
        next = nxt;
    }
    SCCNode getNext() {
        return next;
    }
}

class GroupStack {
    int count;
    StackNode top;
    GroupStack() {
        count = 0;
        top = null;
    }
    int stackSize() {
        return count;
    }
    void push(int elem) {
        StackNode newTop = new StackNode(elem);
        newTop.setNext(top);
        top = newTop;
        count++;
    }
    int[] getElements() {
        int[] members = new int[count];
        StackNode current = top;
        for (int i = 0; current != null; current = current.getNext(), i++) {
            members[i] = current.getValue();
        }
        return members;
    }
    GroupStack splitUntil(int value) {
        int item;
        GroupStack newStack = new GroupStack();
        do {
            item = this.pop();
            newStack.push(item);
        } while (item != value);
        return newStack;
    }
    int pop() {
        int val = top.getValue();
        top = top.getNext();
        count--;
        return val;
    }
    boolean isEmpty() {
        return top == null;
    }
}

class StackNode {
    int value;
    StackNode next;
    StackNode(int val) {
        value = val;
        next = null;
    }
    int getValue() { return value; }
    void setNext(StackNode nxt) { next = nxt; }
    StackNode getNext() { return next; }
}

class GrpManager {
    public static PrintWriter grpWriter = new PrintWriter(System.out, true);
    private static Scanner inputScanner = new Scanner(System.in);
    public static void main(String[] args) {
        initiateScenario();
    }
    private static void initiateScenario() {
        int scenarios, scenarioNo;
        int studentsCount, student;
        StudentNode[] studentNodes;
        int id, friendCount, friends[], i;
        GroupsOutcome outcomes = new GroupsOutcome();
        scenarios = inputScanner.nextInt();
        for (scenarioNo = 1; scenarioNo <= scenarios; scenarioNo++) {
            studentsCount = inputScanner.nextInt();
            studentNodes = new StudentNode[studentsCount];
            for (student = 0; student < studentsCount; student++) {
                id = inputScanner.nextInt();
                friendCount = inputScanner.nextInt();
                friends = new int[friendCount];
                for (i = 0; i < friendCount; i++) {
                    friends[i] = inputScanner.nextInt() - 1;
                }
                studentNodes[id - 1] = new StudentNode(friendCount, friends);
            }
            ScenarioHandler.displayStudents(scenarioNo, studentsCount, studentNodes);
            // The original function for counting and outputting the results is not included for brevity.
        }
        // Original function to output the final outcomes is also adjusted for brevity.
    }
}