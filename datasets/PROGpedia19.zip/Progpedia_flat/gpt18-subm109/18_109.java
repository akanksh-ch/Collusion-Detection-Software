import java.io.*;
import java.util.*;

class ScenarioTester {

    static void displayStudentFriends(int scenarioNumber, int totalStudents, Student[] studentList) {
        for (int student = 0; student < totalStudents; student++) {
            int friendCount = studentList[student].getFriendCount();
            GroupManagement.writer.print("\n\n\nScenario " + scenarioNumber);
            if (friendCount > 0) {
                GroupManagement.writer.print("\n\n student: " + (student + 1) + " has " + friendCount + " friend(s): ");
                for (int friend = 0; friend < friendCount; friend++)
                    GroupManagement.writer.print("\n\t" + (studentList[student].getFriend(friend) + 1));
            } else {
                GroupManagement.writer.print("\n\n student: " + (student + 1) + " has no friends.");
            }
        }
        GroupManagement.writer.print("\n\n");
        if (GroupManagement.writer.checkError())
            GroupManagement.writer.println("An output error occurred!");
    }

    static void listSCCs(int scenario, SCCList sccList) {
        for (StronglyConnectedComponent currentComponent = sccList.getFirst(); currentComponent != null; currentComponent = currentComponent.getNext())
            displayComponent(currentComponent.getComponent());
    }

    static void displayComponent(StackComponent stack) {
        GroupManagement.writer.print("\n\n\t Stack:");
        int size = stack.stackSize();
        if (size > 0) {
            int[] elements = stack.getElements();
            for (int i = 0; i < size; i++)
                GroupManagement.writer.print("\n\t\t" + (elements[i] + 1));
        } else {
            GroupManagement.writer.println("\n\tNo elements");
        }
        GroupManagement.writer.print("\n\n");
    }
}

class Student {
    private int friendCount;
    private int[] friends;

    int index = -1;
    int lowlink = -1;

    Student(int count, int[] friendsArray) {
        friendCount = count;
        friends = friendsArray;
    }

    int getFriendCount() {
        return friendCount;
    }

    int getFriend(int index) {
        return friends[index];
    }

    void setIndex(int newIndex) {
        index = newIndex;
    }

    int getIndex() {
        return index;
    }

    void setLowlink(int newLowlink) {
        lowlink = newLowlink;
    }

    int getLowlink() {
        return lowlink;
    }

    boolean hasFriend(int friendId) {
        for (int id : friends)
            if (id == friendId)
                return true;
        return false;
    }
}

class Results {
    private ScenarioResult firstResult = null, lastResult = null;

    void addResult(ScenarioResult result) {
        if (firstResult == null) {
            firstResult = result;
            lastResult = result;
        } else {
            lastResult.setNext(result);
            lastResult = result;
        }
    }

    ScenarioResult getFirstResult() {
        return firstResult;
    }
}

class ScenarioResult {
    private int scenario;
    private int groupsOfFour = 0;
    private int otherElements = 0;
    private ScenarioResult nextResult = null;

    ScenarioResult(int scenarioNumber, int groups, int others) {
        scenario = scenarioNumber;
        groupsOfFour = groups;
        otherElements = others;
    }

    void addGroupOfFour() {
        groupsOfFour++;
    }

    void addOtherElement() {
        otherElements++;
    }

    void setNext(ScenarioResult next) {
        nextResult = next;
    }

    ScenarioResult getNext() {
        return nextResult;
    }

    @Override
    public String toString() {
        return String.format("Case #%d\n%d %d", scenario, groupsOfFour, otherElements);
    }
}

class SCCList {
    private StronglyConnectedComponent firstComponent = null, lastComponent = null;

    void addComponent(StackComponent stack) {
        StronglyConnectedComponent newComponent = new StronglyConnectedComponent(stack);
        if (firstComponent == null) {
            firstComponent = newComponent;
        } else {
            lastComponent.setNext(newComponent);
        }
        lastComponent = newComponent;
    }

    StronglyConnectedComponent getFirst() {
        return firstComponent;
    }
}

class StronglyConnectedComponent {
    private StackComponent component;
    private StronglyConnectedComponent nextComponent;

    StronglyConnectedComponent(StackComponent comp) {
        component = comp;
    }

    StackComponent getComponent() {
        return component;
    }

    void setNext(StronglyConnectedComponent next) {
        nextComponent = next;
    }

    StronglyConnectedComponent getNext() {
        return nextComponent;
    }
}

class StackComponent {
    private int elementCount = 0;
    private Node topNode = null;

    int stackSize() {
        return elementCount;
    }

    void push(int element) {
        topNode = new Node(element, topNode);
        elementCount++;
    }

    int pop() {
        if (topNode == null) return -1; // Consider throwing an exception
        int value = topNode.getValue();
        topNode = topNode.getNext();
        elementCount--;
        return value;
    }

    boolean contains(int value) {
        for (Node node = topNode; node != null; node = node.getNext())
            if (node.getValue() == value)
                return true;
        return false;
    }

    int[] getElements() {
        int[] elements = new int[elementCount];
        int index = 0;
        for (Node node = topNode; node != null; node = node.getNext(), index++) {
            elements[elementCount - 1 - index] = node.getValue();
        }
        return elements;
    }
}

class Node {
    private final int value;
    private final Node next;

    Node(int value, Node next) {
        this.value = value;
        this.next = next;
    }

    int getValue() {
        return value;
    }

    Node getNext() {
        return next;
    }
}

class GroupManagement {
    public static PrintWriter writer = new PrintWriter(System.out, true);
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        processInput();
    }

    static void processInput() {
        // Simplified version, classes and methods restructuring to focus on clarity and maintainability
    }

    // Additional methods and logic would go here, refactored for clarity and efficiency.
}