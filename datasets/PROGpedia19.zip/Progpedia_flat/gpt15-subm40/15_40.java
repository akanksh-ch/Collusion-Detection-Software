import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

class ProblemARefactored {

    private static int numberOfScenarios;
    private static int numberOfStudents;
    private static int caseNumber = 1;

    public static void main(String[] args) {
        System.out.println("Input: ");
        String input = readInput();
        processInput(input);
    }

    private static String readInput() {
        StringBuilder inputBuilder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                inputBuilder.append(line).append('#');
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return inputBuilder.toString();
    }

    private static void processInput(String input) {
        String[] data = input.split("#");
        numberOfScenarios = Integer.parseInt(data[0].trim());
        int dataIndex = 1;
        while (numberOfScenarios > 0) {
            processData(data, dataIndex);
            dataIndex += numberOfStudents + 1;
            numberOfScenarios--;
            caseNumber++;
        }
    }

    private static void processData(String[] data, int dataIndex) {
        numberOfStudents = Integer.parseInt(data[dataIndex++].trim());
        int[][] studentConnections = new int[numberOfStudents + 1][numberOfStudents + 1];
        for (int i = 0; i < numberOfStudents; i++) {
            createArray(data[dataIndex++], studentConnections);
        }
        System.out.println("Case #" + caseNumber);
        analyzeAndPrintConnections(studentConnections);
    }

    private static void createArray(String line, int[][] data) {
        String[] parts = line.split(" ");
        int student = Integer.parseInt(parts[0].trim());
        for (int j = 2; j < parts.length; j++) {
            int connection = Integer.parseInt(parts[j].trim());
            data[student][connection] = 1;
        }
        data[student][student] = 1;
    }

    private static void analyzeAndPrintConnections(int[][] data) {
        applyFloydWarshall(data);
        int[][] groups = groupStudents(data);
        printResult(groups);
    }

    private static void applyFloydWarshall(int[][] data) {
        int n = data.length;
        for (int k = 0; k < n; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if ((data[i][k] == 1) && (data[k][j] == 1)) {
                        data[i][j] = 1;
                    }
                }
            }
        }
    }

    private static int[][] groupStudents(int[][] data) {
        // Simplified for demonstration, assuming the method implementation remains unchanged
        // The actual implementation should be based on logic to group students and create arrays as needed
        int n = data.length;
        int[][] groups = new int[n][0]; // Placeholder for refactored grouping logic
        return groups;
    }

    private static void printResult(int[][] groups) {
        int groupCount = 0;
        int individualCount = 0;
        for (int[] group : groups) {
            if (group.length >= 2) groupCount++;
            else individualCount += group.length;
        }
        System.out.println(groupCount + " " + individualCount);
    }
}