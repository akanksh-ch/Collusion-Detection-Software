import java.io.*;
import java.util.Scanner;

class MatrixUtils {
    public static void initializeBooleanMatrix(boolean[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < i; j++)
                matrix[i][j] = false;
            matrix[i][i] = true; // Self loops
            for (int j = i + 1; j < matrix.length; j++)
                matrix[i][j] = false;
        }
    }

    public static void populateLinkages(boolean[][] matrix) {
        for (int primary = 0; primary < matrix.length; primary++) {
            for (int secondary = 0; secondary < matrix.length; secondary++) {
                if (matrix[primary][secondary]) {
                    for (int tertiary = 0; tertiary < matrix.length; tertiary++) {
                        if (matrix[secondary][tertiary])
                            matrix[primary][tertiary] = true;
                        if (matrix[tertiary][primary])
                            matrix[tertiary][secondary] = true;
                    }
                }
            }
        }
    }
    
    public static void computeRelationMetrics(boolean[][] matrix, int[] relationshipCounts, boolean[] processed) {
        for (int i = 0; i < matrix.length; i++) {
            relationshipCounts[i] = 0; // Reset relationship count
            for (int j = 0; j < matrix.length; j++) {
                if (matrix[i][j])
                    relationshipCounts[i]++;
            }
        }
        for (int i = 0; i < processed.length; i++) {
            processed[i] = false; // Reset processed flags
        }
    }
    
    public static void displayMetrics(int[] metrics) {
        for (int metric : metrics) {
            System.out.print("[" + metric + "]");
        }
        System.out.println();
    }
    
    public static void displayMatrix(boolean[][] matrix) {
        System.out.print("|||");
        for (int i = 0; i < matrix.length; i++)
            System.out.print("|" + (i + 1) + "|");
        System.out.println();
        
        for (int i = 0; i < matrix.length; i++) {
            System.out.print("|" + (i + 1) + "|");
            for (int j = 0; j < matrix.length; j++) {
                System.out.print("[" + (matrix[i][j] ? 1 : 0) + "]");
            }
            System.out.println();
        }
        System.out.println();
    }
}

class RefactoredMain {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        int totalCases = scanner.nextInt();
        
        for (int caseNum = 1; caseNum <= totalCases; caseNum++) {
            int dimension = scanner.nextInt();
            boolean[][] adjacencyMatrix = new boolean[dimension][dimension];
            MatrixUtils.initializeBooleanMatrix(adjacencyMatrix);

            for (int i = 0; i < dimension; i++) {
                int node = scanner.nextInt() - 1;
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    int connectedNode = scanner.nextInt() - 1;
                    adjacencyMatrix[node][connectedNode] = true;
                }
            }
            
            MatrixUtils.populateLinkages(adjacencyMatrix);

            int[] relationCounts = new int[dimension];
            boolean[] processed = new boolean[dimension];
            MatrixUtils.computeRelationMetrics(adjacencyMatrix, relationCounts, processed);

            int groupCount = 0, outlierCount = 0;
            
            for (int i = 0; i < dimension; i++) {
                if (processed[i]) continue;
                int count = relationCounts[i];
                int sameRelations = 1;
                for (int j = 0; j < dimension; j++) {
                    if (!processed[j] && i != j && relationCounts[j] == count) {
                        boolean identical = true;
                        for (int k = 0; k < dimension; k++) {
                            identical &= adjacencyMatrix[i][k] == adjacencyMatrix[j][k];
                            if (!identical) break;
                        }
                        if (identical) {
                            processed[i] = true;
                            processed[j] = true;
                            sameRelations++;
                        }
                    }
                }
                if (sameRelations < 4)
                    outlierCount += sameRelations;
                else
                    groupCount++;
            }
            
            System.out.println("Case #" + caseNum + "\n" + groupCount + " " + outlierCount);
        }
    }
}