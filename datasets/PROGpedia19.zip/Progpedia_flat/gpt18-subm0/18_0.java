import java.util.*;

class GraphProcessor {
    private Scanner scanner;
    private int nodeCount;
    private int componentSize;
    private boolean[] visited;
    private Deque<Integer> topoOrder = new LinkedList<>();
    private List<Integer> componentNodes = new LinkedList<>();
    private Map<Integer, Integer> nodeIndexMap = new HashMap<>();
    private List<List<Integer>> adjacencyList = new ArrayList<>();
    private List<List<Integer>> transposedAdjList = new ArrayList<>();

    public GraphProcessor(Scanner scanner) {
        this.scanner = scanner;
    }

    private int addOrGetNodeIndex(int node) {
        return nodeIndexMap.computeIfAbsent(node, k -> {
            adjacencyList.add(new LinkedList<>());
            transposedAdjList.add(new LinkedList<>());
            return nodeIndexMap.size();
        });
    }

    public void readGraph() {
        nodeCount = scanner.nextInt();
        nodeIndexMap.clear();
        adjacencyList.clear();
        transposedAdjList.clear();

        for (int i = 0; i < nodeCount; i++) {
            int node = addOrGetNodeIndex(scanner.nextInt());
            int connectionCount = scanner.nextInt();
            for (int j = 0; j < connectionCount; j++) {
                int targetNode = addOrGetNodeIndex(scanner.nextInt());
                adjacencyList.get(node).add(targetNode);
                transposedAdjList.get(targetNode).add(node);
            }
        }

        nodeCount = nodeIndexMap.size();
    }

    private void depthFirstSearch(int node) {
        if (visited[node]) return;
        visited[node] = true;

        for (int neighbor : adjacencyList.get(node)) {
            if (!visited[neighbor]) depthFirstSearch(neighbor);
        }
        topoOrder.addFirst(node);
    }

    private void markComponent(int node) {
        componentSize++;
        visited[node] = true;
        for (int neighbor : transposedAdjList.get(node)) {
            if (!visited[neighbor]) markComponent(neighbor);
        }
    }

    public void process() {
        topoOrder.clear();
        visited = new boolean[nodeCount];
        Arrays.fill(visited, false);
        
        for (int i = 0; i < nodeCount; i++) depthFirstSearch(i);

        Arrays.fill(visited, false);
        int largeComponents = 0, smallComponentsSum = 0;

        for (int node : topoOrder) {
            if (!visited[node]) {
                componentSize = 0;
                markComponent(node);
                if (componentSize >= 4) largeComponents++;
                else smallComponentsSum += componentSize;
            }
        }

        System.out.printf("%d %d\n", largeComponents, smallComponentsSum);
    }
}

class GraphComponentsCounter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GraphProcessor processor = new GraphProcessor(scanner);
        int testCases = scanner.nextInt();
        for (int i = 1; i <= testCases; i++) {
            System.out.printf("Case#%d\n", i);
            processor.readGraph();
            processor.process();
        }
    }
}