import java.io.IOException;
import java.util.Arrays;

class NetworkAnalysis {

    private static int scenarioCount = 0;
    private static String inputData = "";

    public static String getInputData() throws IOException {
        StringBuilder inputData = new StringBuilder();
        int character;
        boolean done = false;
        while (!done) {
            character = System.in.read();
            if (character < 0 || (char) character == '\n')
                done = true;
            else if ((char) character != '\r')
                inputData.append((char) character);
        }
        return inputData.toString();
    }

    public static void main(String[] args) throws IOException {
        System.out.println("Input data:");
        inputData = getInputData();
        processInputData();
    }

    private static void processInputData() {
        String[] scenarios = inputData.split("#");
        scenarioCount = Integer.parseInt(scenarios[0].trim());
        int currentScenario = 1;
        int lineIndex = 1;

        while (scenarioCount > 0) {
            int students = Integer.parseInt(scenarios[lineIndex++].trim());
            int[][] networkData = new int[students + 1][students + 1];

            for (int student = students; student > 0; student--) {
                String connectionData = scenarios[lineIndex++];
                networkData = populateNetwork(connectionData, networkData);
            }

            System.out.println("Scenario #" + currentScenario);
            resolveNetworkConnections(networkData);

            scenarioCount--;
            currentScenario++;
        }
    }

    private static int[][] populateNetwork(String connectionInfo, int[][] matrix) {
        String[] data = connectionInfo.split(" ");
        int primary = Integer.parseInt(data[0].trim());

        for (int index = 2; index < data.length; index++) {
            int connectedTo = Integer.parseInt(data[index].trim());
            matrix[primary][connectedTo] = 1;
        }
        matrix[primary][primary] = 1;

        return matrix;
    }

    private static void resolveNetworkConnections(int[][] network) {
        applyFloydWarshall(network);
        analyzeGroups(network);
    }

    private static void analyzeGroups(int[][] network) {
        int[][] grouping = initializeGrouping(network.length);
        findAndMergeGroups(network, grouping);
        displayResults(grouping);
    }

    private static int[][] initializeGrouping(int size) {
        return new int[size][0];
    }

    private static void findAndMergeGroups(int[][] network, int[][] groups) {
        for (int i = 1; i < network.length; i++) {
            for (int j = 1; j < network.length; j++) {
                if (i != j && network[i][j] == 1) {
                    groups = processConnection(groups, i, j, network[j][i] == 1);
                    network[j][i] = 0; // Prevent reprocessing
                }
            }
        }
    }

    private static int[][] processConnection(int[][] groups, int from, int to, boolean reciprocal) {
        if (reciprocal) {
            groups = mergeOrAdd(groups, from, to);
        } else {
            groups = addToSeparate(groups, from, to);
        }
        return groups;
    }

    private static int[][] mergeOrAdd(int[][] groups, int id1, int id2) {
        // Unified processing to either merge groups or add elements into a new/existing group
        return updateGroups(groups, id1, id2, true);
    }

    private static int[][] addToSeparate(int[][] groups, int id1, int id2) {
        // Process adding to separate groups handling bidirectionality if needed
        return updateGroups(groups, id1, id2, false);
    }

    private static int[][] updateGroups(int[][] groups, int id1, int id2, boolean merge) {
        // Refactored complex group manipulation logic
        return merge ? handleMerge(groups, id1, id2) : handleSeparateAddition(groups, id1, id2);
    }

    private static int[][] handleMerge(int[][] groups, int id1, int id2) {
        // Implementation for merging logic
        // Simulated functionality, needs detailed implementation based on original merging logic
        return groups;
    }

    private static int[][] handleSeparateAddition(int[][] groups, int id1, int id2) {
        // Simulated functionality for adding to separate groups based on condition
        return groups;
    }

    private static void applyFloydWarshall(int[][] network) {
        for (int k = 0; k < network.length; k++)
            for (int i = 0; i < network.length; i++)
                for (int j = 0; j < network.length; j++) {
                    if ((network[i][k] + network[k][j]) == 2) {
                        network[i][j] = 1;
                    }
                }
    }

    private static void displayResults(int[][] groups) {
        int totalGroups = countGroups(groups);
        System.out.println(totalGroups + " groups detected.");
    }

    private static int countGroups(int[][] groups) {
        // Implementation to count actual groups based on simplified logic for illustration
        return groups.length; // Placeholder
    }
}