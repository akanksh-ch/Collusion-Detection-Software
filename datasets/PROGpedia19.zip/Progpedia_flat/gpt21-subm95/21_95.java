import java.io.*;
import java.util.Scanner;

class MatrixUtilities {
    static void clearBooleanMatrix(boolean[] matrix) {
        for (int index = 0; index < matrix.length; index++) {
            matrix[index] = false;
        }
    }

    static void initializeIntMatrix(int[] matrix) {
        java.util.Arrays.fill(matrix, 0);
    }

    static void populateIncidenceMatrix(boolean[][] relations, int[] incidence, int dimension) {
        for (int row = 0; row < dimension; row++) {
            for (int column = 0; column < dimension; column++) {
                if (relations[row][column]) incidence[row]++;
            }
        }
    }

    static void printIncidenceMatrix(int[] incidence) {
        for (int count : incidence) System.out.print("[" + count + "]");
        System.out.println();
    }

    static void expandRelations(boolean[][] relations, int dimension) {
        for (int row = 0; row < dimension; row++) {
            for (int column = 0; column < dimension; column++) {
                if (relations[row][column]) {
                    for (int scan = 0; scan < dimension; scan++) {
                        relations[row][scan] |= relations[column][scan];
                        relations[scan][column] |= relations[scan][row];
                    }
                }
            }
        }
    }

    static void resetBooleanMatrix(boolean[][] relations, int dimension) {
        for (int row = 0; row < dimension; row++) {
            relations[row][row] = true;
            for (int column = 0; column < dimension; column++) {
                if (row != column) relations[row][column] = false;
            }
        }
    }

    static void displayMatrix(boolean[][] relations, int dimension) {
        StringBuilder builder = new StringBuilder("|||");
        for (int num = 1; num <= dimension; num++) builder.append("|").append(num).append("|");
        builder.append("\n");
        for (int row = 0; row < dimension; row++) {
            builder.append("|").append(row + 1).append("|");
            for (boolean cell : relations[row]) {
                builder.append("[").append(cell ? 1 : 0).append("]");
            }
            builder.append("\n");
        }
        System.out.println(builder);
    }
}

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int testCases = scanner.nextInt();
        for (int testCase = 1; testCase <= testCases; testCase++) {
            int dimension = scanner.nextInt();
            boolean[][] relations = new boolean[dimension][dimension];
            MatrixUtilities.resetBooleanMatrix(relations, dimension);
            for (int i = 0; i < dimension; i++) {
                int node = scanner.nextInt() - 1;
                int edges = scanner.nextInt();
                for (int edge = 0; edge < edges; edge++) {
                    int connectedNode = scanner.nextInt() - 1;
                    relations[node][connectedNode] = true;
                }
            }
            MatrixUtilities.expandRelations(relations, dimension);
            int[] incidence = new int[dimension];
            boolean[] visited = new boolean[dimension];
            MatrixUtilities.initializeIntMatrix(incidence);
            MatrixUtilities.clearBooleanMatrix(visited);
            MatrixUtilities.populateIncidenceMatrix(relations, incidence, dimension);
            int groups = 0, outliers = 0;
            for (int node = 0; node < dimension; node++) {
                if (visited[node]) continue;
                int relationsCount = incidence[node];
                int memberCount = 1;
                for (int compareNode = 0; compareNode < dimension; compareNode++) {
                    if (!visited[compareNode] && node != compareNode && incidence[node] == incidence[compareNode]) {
                        boolean similar = true;
                        for (int relation = 0; relation < dimension; relation++) {
                            if (relations[node][relation] != relations[compareNode][relation]) {
                                similar = false;
                                break;
                            }
                        }
                        if (similar) {
                            visited[node] = true;
                            visited[compareNode] = true;
                            memberCount++;
                        }
                    }
                }
                if (memberCount < 4) outliers += memberCount;
                else groups++;
            }
            System.out.println("Caso #" + testCase + "\n" + groups + " " + outliers);
        }
    }
}