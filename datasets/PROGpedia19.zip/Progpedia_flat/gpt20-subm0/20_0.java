import java.util.*;

class GraphSolver {
    private Scanner scanner;
    private int nodeCount;
    private boolean[] visited;
    private Deque<Integer> topoSortedNodes = new LinkedList<>();
    private HashMap<Integer, Integer> nodeIndexMap = new HashMap<>();
    private List<List<Integer>> adjacencyList = new ArrayList<>();
    private List<List<Integer>> transposedAdjacencyList = new ArrayList<>();

    GraphSolver(Scanner scanner) {
        this.scanner = scanner;
    }

    private int getNodeIndex(int node) {
        if (!nodeIndexMap.containsKey(node)) {
            int newIndex = nodeIndexMap.size();
            nodeIndexMap.put(node, newIndex);
            adjacencyList.add(new LinkedList<>());
            transposedAdjacencyList.add(new LinkedList<>());
        }
        return nodeIndexMap.get(node);
    }

    void readGraph() {
        nodeCount = scanner.nextInt();
        nodeIndexMap.clear();
        adjacencyList.clear();
        transposedAdjacencyList.clear();
        for (int i = 0; i < nodeCount; i++) {
            int fromNode = getNodeIndex(scanner.nextInt());
            int edgesCount = scanner.nextInt();
            for (int j = 0; j < edgesCount; j++) {
                int toNode = getNodeIndex(scanner.nextInt());
                adjacencyList.get(fromNode).add(toNode);
                transposedAdjacencyList.get(toNode).add(fromNode);
            }
        }
        nodeCount = nodeIndexMap.size();
    }

    private void depthFirstSearch(int node) {
        if (visited[node]) return;
        visited[node] = true;
        for (int neighbor : adjacencyList.get(node)) {
            if (!visited[neighbor]) {
                depthFirstSearch(neighbor);
            }
        }
        topoSortedNodes.addFirst(node);
    }

    private void floodFill(int node) {
        visited[node] = true;
        for (int neighbor : transposedAdjacencyList.get(node)) {
            if (!visited[neighbor]) {
                floodFill(neighbor);
            }
        }
    }

    void solve() {
        topoSortedNodes.clear();
        visited = new boolean[nodeCount];
        Arrays.fill(visited, false);

        for (int i = 0; i < nodeCount; i++) {
            depthFirstSearch(i);
        }
        Arrays.fill(visited, false);

        int largeComponents = 0, smallComponents = 0;
        for (int node : topoSortedNodes) {
            if (!visited[node]) {
                int componentSize = 0;
                floodFill(node);
                componentSize++;
                if (componentSize >= 4) {
                    largeComponents++;
                } else {
                    smallComponents += componentSize;
                }
            }
        }
        System.out.printf("%d %d\n", largeComponents, smallComponents);
    }
}

class ProblemSolver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GraphSolver graphSolver = new GraphSolver(scanner);
        int testCases = scanner.nextInt();
        for (int i = 1; i <= testCases; i++) {
            System.out.printf("Case#%d\n", i);
            graphSolver.readGraph();
            graphSolver.solve();
        }
    }
}