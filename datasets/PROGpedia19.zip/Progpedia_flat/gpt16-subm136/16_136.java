import java.util.*;

class Graph {
    public static final int DIM = 1000;
    List<List<Integer>> adj;
    int[] color, parent, startTime, finishTime;
    int time;

    Graph() {
        adj = new ArrayList<>(Collections.nCopies(DIM, null));
        color = new int[DIM];
        parent = new int[DIM];
        startTime = new int[DIM];
        finishTime = new int[DIM];
    }

    Graph transpose() {
        Graph transposed = new Graph();
        for (int i = 0; i < adj.size() && adj.get(i) != null; i++) {
            transposed.adj.set(i, new ArrayList<>());
        }
        for (int i = 0; i < adj.size() && adj.get(i) != null; i++) {
            for (Integer node : adj.get(i)) {
                transposed.adj.get(node).add(i);
            }
        }
        return transposed;
    }

    void depthFirstSearch(List<Integer> fst, List<Integer> snd) {
        Arrays.fill(color, 0);
        Arrays.fill(parent, -1);
        Arrays.fill(startTime, -1);
        Arrays.fill(finishTime, -1);
        time = 0;
        for (Integer source : fst) {
            if (color[source] == 0) {
                depthFirstVisit(source, snd);
            }
        }
    }

    void depthFirstVisit(int source, List<Integer> snd) {
        color[source] = 1;
        time += 1;
        startTime[source] = time;
        for (Integer node : adj.get(source)) {
            if (color[node] == 0) {
                parent[node] = source;
                depthFirstVisit(node, snd);
            }
        }
        color[source] = 2;
        time += 1;
        finishTime[source] = time;
        snd.add(0, source);
    }

    PriorityQueue<Integer> findValues(int value, int[] vtr) {
        PriorityQueue<Integer> fila = new PriorityQueue<>();
        for (int i = 0; i < adj.size() && adj.get(i) != null; i++)
            if (vtr[i] == value)
                fila.add(i);
        return fila;
    }

    void makeTree(List<List<Integer>> tree, int index, int value) {
        if (value != -1)
            tree.get(index).add(value);
        PriorityQueue<Integer> fila = findValues(value, parent);
        while (!fila.isEmpty()) {
            int newValue = fila.remove();
            makeTree(tree, index, newValue);
        }
    }

    List<List<Integer>> buildTreeForest() {
        List<List<Integer>> tree = new ArrayList<>(Collections.nCopies(DIM, null));
        for (int i = 0; i < adj.size() && adj.get(i) != null; i++) {
            if (parent[i] == -1) {
                tree.set(i, new ArrayList<>());
                makeTree(tree, i, i);
            }
        }
        tree.removeIf(Objects::isNull);
        return tree;
    }
}

class Sociologia {
    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        int nCenarios = inp.nextInt();
        for (int i = 0; i < nCenarios; i++) {
            List<Integer> fst = new LinkedList<>();
            List<Integer> snd = new LinkedList<>();
            Graph sociologia = new Graph();
            int nAlunos = inp.nextInt();
            for (int j = 0; j < nAlunos; j++) {
                sociologia.adj.set(j, new LinkedList<>());
                fst.add(j);
            }
            for (int j = 0; j < nAlunos; j++) {
                int aluno = inp.nextInt();
                int nAmigos = inp.nextInt();
                for (int k = 0; k < nAmigos; k++) {
                    sociologia.adj.get(aluno - 1).add(inp.nextInt() - 1);
                }
            }
            sociologia.depthFirstSearch(fst, snd);
            Graph sociologiaT = sociologia.transpose();
            sociologiaT.depthFirstSearch(snd, new LinkedList<>());
            List<List<Integer>> groups = sociologiaT.buildTreeForest();
            int count = 0;
            int nGroups = 0;
            int nElemOut = 0;
            System.out.printf("Caso #%d\n", i + 1);
            for (List<Integer> group : groups) {
                count = group.size();
                if (count >= 4) {
                    nGroups += 1;
                } else {
                    nElemOut += count;
                }
            }
            System.out.printf("%d %d\n", nGroups, nElemOut);
        }
    }
}