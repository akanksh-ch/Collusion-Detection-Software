import java.util.*;
class NetworkAnalysis {
    private static final int MAX_NODES = 1000;
    List<Integer>[] adjacencyList = new List[MAX_NODES];
    int[] state, predecessor, entryTime, exitTime;
    int clockTick;

    NetworkAnalysis() {
        for (int i = 0; i < MAX_NODES; ++i) {
            adjacencyList[i] = new LinkedList<>();
        }
        state = new int[MAX_NODES];
        predecessor = new int[MAX_NODES];
        entryTime = new int[MAX_NODES];
        exitTime = new int[MAX_NODES];
    }

    NetworkAnalysis reverseGraph() {
        NetworkAnalysis reversed = new NetworkAnalysis();
        for (int i = 0; i < MAX_NODES && !adjacencyList[i].isEmpty(); ++i) {
            for (int adjacentNode : adjacencyList[i]) {
                reversed.adjacencyList[adjacentNode].add(i);
            }
        }
        return reversed;
    }

    void executeDFS(List<Integer> order, List<Integer> output) {
        Arrays.fill(state, 0);
        Arrays.fill(predecessor, -1);
        Arrays.fill(entryTime, 0);
        Arrays.fill(exitTime, 0);
        clockTick = 0;
        for (int node : order) {
            if (state[node] == 0) explore(node, output);
        }
    }

    private void explore(int node, List<Integer> output) {
        state[node] = 1;
        entryTime[node] = ++clockTick;
        for (int neighbor : adjacencyList[node]) {
            if (state[neighbor] == 0) {
                predecessor[neighbor] = node;
                explore(neighbor, output);
            }
        }
        state[node] = 2;
        exitTime[node] = ++clockTick;
        output.add(0, node);
    }

    PriorityQueue<Integer> searchNodesByValue(int targetValue, int[] sequence) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();
        for (int i = 0; i < MAX_NODES && adjacencyList[i] != null; ++i) {
            if (sequence[i] == targetValue) queue.add(i);
        }
        return queue;
    }

    void buildTree(List<Integer> tree, int value) {
        if (value != -1) tree.add(value);
        PriorityQueue<Integer> queue = searchNodesByValue(value, predecessor);
        while (!queue.isEmpty()) {
            buildTree(tree, queue.poll());
        }
    }

    List<Integer>[] constructForest() {
        List<Integer>[] forest = new List[MAX_NODES];
        for (int i = 0; i < MAX_NODES && !adjacencyList[i].isEmpty(); ++i) {
            if (predecessor[i] == -1) {
                forest[i] = new LinkedList<>();
                buildTree(forest[i], i);
            }
        }
        return forest;
    }
}

class SociologyStudy {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();
        for (int scenario = 0; scenario < scenarios; ++scenario) {
            List<Integer> initialOrder = new LinkedList<>();
            List<Integer> transposedOrder = new LinkedList<>();
            NetworkAnalysis graph = new NetworkAnalysis();
            int numStudents = scanner.nextInt();
            for (int student = 0; student < numStudents; ++student) {
                initialOrder.add(student);
            }
            for (int student = 0; student < numStudents; ++student) {
                int studentId = scanner.nextInt() - 1;
                int friendsCount = scanner.nextInt();
                for (int friend = 0; friend < friendsCount; ++friend) {
                    graph.adjacencyList[studentId].add(scanner.nextInt() - 1);
                }
            }
            graph.executeDFS(initialOrder, transposedOrder);
            NetworkAnalysis reversedGraph = graph.reverseGraph();
            initialOrder.clear(); 
            reversedGraph.executeDFS(transposedOrder, initialOrder);
            List<Integer>[] groups = reversedGraph.constructForest();
            int groupCounter = 0, singleElements = 0;
            System.out.printf("Scenario #%d\n", scenario + 1);
            for (List<Integer> group : groups) {
                if (group == null) break;
                int size = group.size();
                if (size >= 4) groupCounter++;
                else singleElements += size;
            }
            System.out.printf("%d %d\n", groupCounter, singleElements);
        }
        scanner.close();
    }
}