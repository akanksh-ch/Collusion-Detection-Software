import java.util.*;

class Graph {
    private static final int SIZE = 1000;
    List<Integer>[] adjacencies;
    int[] color, parent, discoveryTime, finishTime;
    int time;

    Graph() {
        adjacencies = (LinkedList<Integer>[]) new LinkedList[SIZE];
        color = new int[SIZE];
        parent = new int[SIZE];
        discoveryTime = new int[SIZE];
        finishTime = new int[SIZE];
        for (int i = 0; i < SIZE; i++) {
            adjacencies[i] = new LinkedList<>();
        }
    }

    Graph getTransposedGraph() {
        Graph transposed = new Graph();
        for (int i = 0; i < adjacencies.length && adjacencies[i] != null; i++) {
            for (int node : adjacencies[i]) {
                transposed.adjacencies[node].add(i);
            }
        }
        return transposed;
    }
    
    void depthFirstSearch(List<Integer> sources, List<Integer> order) {
        Arrays.fill(color, 0);
        Arrays.fill(parent, -1);
        Arrays.fill(discoveryTime, -1);
        Arrays.fill(finishTime, -1);
        time = 0;
        for (int source : sources) {
            if (color[source] == 0) {
                visit(source, order);
            }
        }
    }

    private void visit(int node, List<Integer> order) {
        color[node] = 1;
        discoveryTime[node] = ++time;
        for (int adjNode : adjacencies[node]) {
            if (color[adjNode] == 0) {
                parent[adjNode] = node;
                visit(adjNode, order);
            }
        }
        color[node] = 2;
        finishTime[node] = ++time;
        order.add(0, node);
    }

    PriorityQueue<Integer> findNodesWithValue(int value) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();
        for (int i = 0; i < adjacencies.length && adjacencies[i] != null; i++) {
            if (parent[i] == value) queue.add(i);
        }
        return queue;
    }

    void buildTree(List<Integer> tree, int rootValue) {
        if (rootValue != -1) tree.add(rootValue);
        PriorityQueue<Integer> children = findNodesWithValue(rootValue);
        while (!children.isEmpty()) {
            buildTree(tree, children.poll());
        }
    }

    List<Integer>[] buildForest() {
        List<Integer>[] forest = (LinkedList<Integer>[]) new LinkedList[SIZE];
        int index = 0;
        for (int i = 0; i < adjacencies.length && adjacencies[i] != null; i++) {
            if (parent[i] == -1) {
                forest[index] = new LinkedList<>();
                buildTree(forest[index], i);
                index++;
            }
        }
        return Arrays.copyOf(forest, index); // Return only the non-null part of the forest
    }
}

class Sociology {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();
        for (int scenarioIndex = 0; scenarioIndex < scenarios; scenarioIndex++) {
            List<Integer> initialList = new LinkedList<>();
            List<Integer> reverseOrderList = new LinkedList<>();
            Graph graph = new Graph();
            int students = scanner.nextInt();
            for (int studentIndex = 0; studentIndex < students; studentIndex++) {
                initialList.add(studentIndex);
            }
            for (int friendIndex = 0; friendIndex < students; friendIndex++) {
                int student = scanner.nextInt() - 1;
                int friendsCount = scanner.nextInt();
                for (int i = 0; i < friendsCount; i++) {
                    graph.adjacencies[student].add(scanner.nextInt() - 1);
                }
            }

            graph.depthFirstSearch(initialList, reverseOrderList);
            Graph transposedGraph = graph.getTransposedGraph();
            transposedGraph.depthFirstSearch(reverseOrderList, new LinkedList<>());
            List<Integer>[] groups = transposedGraph.buildForest();

            int groupCount = 0, soloCount = 0;
            for (List<Integer> group : groups) {
                if (group != null) {
                    if (group.size() >= 4) {
                        groupCount++;
                    } else {
                        soloCount += group.size();
                    }
                }
            }
            System.out.printf("Case #%d\n", scenarioIndex + 1);
            System.out.printf("%d %d\n", groupCount, soloCount);
        }
    }
}