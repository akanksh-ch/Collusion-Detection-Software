import java.util.Scanner;

class GraphAnalyzer {
    
    private static void initializeCheckArray(boolean[] isChecked, int size) {
        for (int i = 0; i < size; i++) isChecked[i] = false;
    }

    private static void clearCounts(int[] counts, int size) {
        java.util.Arrays.fill(counts, 0);
    }

    private static void calculateCounts(boolean[][] grid, int[] counts, int size) {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (grid[row][col]) counts[row]++;
            }
        }
    }

    private static void outputCounts(int[] counts) {
        for (int count : counts) System.out.print("[" + count + "]");
        System.out.println();
    }

    private static void enhanceConnections(boolean[][] grid, int size) {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (grid[row][col]) {
                    for (int k = 0; k < size; k++) {
                        grid[row][k] |= grid[col][k];
                        grid[k][col] |= grid[k][row];
                    }
                }
            }
        }
    }

    private static void clearGrid(boolean[][] grid, int size) {
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) grid[row][col] = row == col;
        }
    }
    
    private static void displayGrid(boolean[][] grid, int size) {
        System.out.print("|||");
        for (int i = 1; i <= size; i++) System.out.print("|" + i + "|");
        System.out.println();
        for (int row = 0; row < size; row++) {
            System.out.print("|" + (row + 1) + "|");
            for (int col = 0; col < size; col++) {
                System.out.print("[" + (grid[row][col] ? 1 : 0) + "]");
            }
            System.out.println();
        }
        System.out.println();
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int scenarios = scanner.nextInt();
            for (int s = 1; s <= scenarios; s++) {
                int dimension = scanner.nextInt();
                boolean[][] grid = new boolean[dimension][dimension];
                clearGrid(grid, dimension);
                for (int i = 0; i < dimension; i++) {
                    int node = scanner.nextInt() - 1;
                    int connections = scanner.nextInt();
                    for (int j = 0; j < connections; j++) {
                        grid[node][scanner.nextInt() - 1] = true;
                    }
                }

                enhanceConnections(grid, dimension);
                
                int[] counts = new int[dimension];
                boolean[] checked = new boolean[dimension];
                clearCounts(counts, dimension);
                initializeCheckArray(checked, dimension);
                calculateCounts(grid, counts, dimension);
                
                int groups = 0, outliers = 0;
                for (int c = 0; c < dimension; c++) {
                    if (checked[c]) continue;
                    int relations = counts[c];
                    int countElements = 1;
                    for (int d = 0; d < dimension; d++) {
                        if (!checked[d] && c != d && counts[c] == counts[d]) {
                            boolean isEqual = true;
                            for (int k = 0; k < dimension; k++) {
                                if ((grid[c][k] != grid[d][k])) {
                                    isEqual = false;
                                    break;
                                }
                            }
                            if (isEqual) {
                                checked[c] = checked[d] = true;
                                countElements++;
                            }
                        }
                    }
                    if (countElements < 4) outliers += countElements;
                    else groups++;
                }
                System.out.println("Case #" + s + "\n" + groups + " " + outliers);
            }
        }
    }
}