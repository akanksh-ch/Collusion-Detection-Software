import java.util.*;

class Graph {
    private static final int DIM = 1000;
    private List<LinkedList<Integer>> adj;
    private int[] color, parent, startTime, finishTime;
    private int time;

    Graph() {
        adj = new ArrayList<>(Collections.nCopies(DIM, null));
        color = new int[DIM];
        parent = new int[DIM];
        startTime = new int[DIM];
        finishTime = new int[DIM];
        Arrays.fill(parent, -1);
        Arrays.fill(startTime, -1);
        Arrays.fill(finishTime, -1);
    }

    Graph transpose() {
        Graph transposed = new Graph();
        for (int i = 0; i < adj.size() && adj.get(i) != null; i++) {
            transposed.adj.set(i, new LinkedList<>());
        }
        for (int i = 0; i < adj.size() && adj.get(i) != null; i++) {
            for (int node : adj.get(i)) {
                transposed.adj.get(node).addLast(i);
            }
        }
        return transposed;
    }

    void depthFirstSearch(LinkedList<Integer> sources) {
        Arrays.fill(color, 0);
        time = 0;
        for (int source : sources) {
            if (color[source] == 0) depthFirstVisit(source);
        }
    }

    private void depthFirstVisit(int source) {
        color[source] = 1;
        startTime[source] = ++time;
        for (int node : adj.get(source)) {
            if (color[node] == 0) {
                parent[node] = source;
                depthFirstVisit(node);
            }
        }
        color[source] = 2;
        finishTime[source] = ++time;
    }

    LinkedList<Integer>[] buildTreeForest() {
        LinkedList<Integer>[] tree = new LinkedList[DIM];
        for (int i = 0; i < adj.size() && adj.get(i) != null; i++) {
            if (parent[i] == -1) {
                tree[i] = new LinkedList<>();
                makeTree(tree[i], i);
            }
        }
        return tree;
    }

    void makeTree(LinkedList<Integer> tree, int value) {
        if (value != -1) tree.add(value);
        for (int i = 0; i < parent.length; i++) {
            if (parent[i] == value) makeTree(tree, i);
        }
    }

    void addEdge(int from, int to) {
        if (adj.get(from) == null) {
            adj.set(from, new LinkedList<>());
        }
        adj.get(from).add(to);
    }
}

class Sociologia {

    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        int nCenarios = inp.nextInt();
        for (int scenario = 1; scenario <= nCenarios; scenario++) {
            int nAlunos = inp.nextInt();
            Graph sociologia = new Graph();
            
            for (int alunoId = 0; alunoId < nAlunos; alunoId++) {
                sociologia.addEdge(alunoId, alunoId); // Initialize adjacency lists with self-reference if needed
                int nAmigos = inp.nextInt();
                for (int amigo = 0; amigo < nAmigos; amigo++) {
                    sociologia.addEdge(alunoId, inp.nextInt() - 1);
                }
            }

            LinkedList<Integer> order = new LinkedList<>();
            for (int i = 0; i < nAlunos; i++) order.addLast(i);
            
            sociologia.depthFirstSearch(order);
            Graph transposed = sociologia.transpose();
            order.clear(); // Consider reusing or appropriately clearing 'order' for the second DFS
            transposed.depthFirstSearch(order);
        }
        // Continue with scenario processing as before
        // Further refinements would be made based on specifics beyond the provided code
    }
}