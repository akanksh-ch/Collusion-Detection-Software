import java.io.*;
import java.util.*;

class Grupos {
    public static PrintWriter pw = new PrintWriter(System.out, true);
    private static Scanner sca = new Scanner(System.in);

    public static void main(String[] args) {
        executeScenarios();
    }

    private static void executeScenarios() {
        int nScenarios = sca.nextInt();
        for (int scenario = 1; scenario <= nScenarios; scenario++) {
            int nStudents = sca.nextInt();
            Student[] students = new Student[nStudents];
            for (int studentId = 0; studentId < nStudents; studentId++) {
                students[studentId] = new Student(sca.nextInt(), readFriendsArray(sca.nextInt()));
            }
            Display.showStudents(scenario, nStudents, students);
            GroupCounter.addResult(scenario, students);
        }
        Display.showResults(GroupCounter.getResults());
    }

    private static int[] readFriendsArray(int nFriends) {
        int[] friends = new int[nFriends];
        for (int i = 0; i < nFriends; i++) {
            friends[i] = sca.nextInt() - 1;
        }
        return friends;
    }
}

class Display {
    static void showStudents(int scenario, int nStudents, Student[] students) {
        Grupos.pw.println("\n\n\nScenario " + scenario);
        for (int student = 0; student < nStudents; student++) {
            int nFriends = students[student].getNumberOfFriends();
            if (nFriends > 0) {
                Grupos.pw.println("\n Student " + (student + 1) + " has " + nFriends + " friend(s): ");
                students[student].printFriends();
            } else {
                Grupos.pw.println("\n Student " + (student + 1) + " has no friends.");
            }
        }
    }

    static void showResults(Results results) {
        for (Result result : results.getAllResults()) {
            Grupos.pw.println("Scenario #" + result.getScenario() + "\n" + result.getGroupsOf4() + " " + result.getOtherElements());
        }
    }
}

class Student {
    private int numberOfFriends;
    private int[] friends;

    Student(int id, int[] friends) {
        this.numberOfFriends = friends.length;
        this.friends = friends;
    }

    int getNumberOfFriends() {
        return numberOfFriends;
    }

    void printFriends() {
        for (int friend : friends) {
            Grupos.pw.println("\t" + (friend + 1));
        }
    }
}

class GroupCounter {
    private static Results results = new Results();

    static void addResult(int scenario, Student[] students) {
        // Simulate group counting logic to keep the example concise
        // Assume some logic here that analyzes student groups
        results.add(new Result(scenario, calculateGroupsOf4(students), calculateOtherElements(students)));
    }

    private static int calculateGroupsOf4(Student[] students) {
        // Placeholder for actual logic
        return 0;
    }

    private static int calculateOtherElements(Student[] students) {
        // Placeholder for actual logic
        return 0;
    }

    public static Results getResults() {
        return results;
    }
}

class Results {
    private List<Result> resultList = new ArrayList<>();

    void add(Result result) {
        resultList.add(result);
    }

    List<Result> getAllResults() {
        return resultList;
    }
}

class Result {
    private int scenario;
    private int groupsOf4;
    private int otherElements;

    Result(int scenario, int groupsOf4, int otherElements) {
        this.scenario = scenario;
        this.groupsOf4 = groupsOf4;
        this.otherElements = otherElements;
    }

    int getScenario() {
        return scenario;
    }

    int getGroupsOf4() {
        return groupsOf4;
    }

    int getOtherElements() {
        return otherElements;
    }
}