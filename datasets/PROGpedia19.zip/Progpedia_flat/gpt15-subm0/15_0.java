import java.util.*;

class GraphSolver {
    private Scanner scanner;
    private int nodeCount;
    private boolean[] visited;
    private Deque<Integer> order = new LinkedList<>();
    private Map<Integer, Integer> nodeMap = new HashMap<>();
    private List<List<Integer>> adjacencyList = new ArrayList<>();
    private List<List<Integer>> transposedList = new ArrayList<>();
    
    GraphSolver(Scanner scanner) {
        this.scanner = scanner;
    }
    
    private int findOrCreateNode(int u) {
        return nodeMap.computeIfAbsent(u, k -> {
            adjacencyList.add(new LinkedList<>());
            transposedList.add(new LinkedList<>());
            return nodeMap.size();
        });
    }
    
    void readGraph() {
        int edges = scanner.nextInt();
        nodeMap.clear();
        adjacencyList.clear();
        transposedList.clear();
        for (int i = 0; i < edges; i++) {
            int from = findOrCreateNode(scanner.nextInt());
            int connections = scanner.nextInt();
            for (int k = 0; k < connections; k++) {
                int to = findOrCreateNode(scanner.nextInt());
                adjacencyList.get(from).add(to);
                transposedList.get(to).add(from);
            }
        }
        nodeCount = nodeMap.size();
    }
    
    private void depthFirstSearch(int u) {
        if (visited[u]) return;
        visited[u] = true;
        for (int v : adjacencyList.get(u)) {
            if (!visited[v]) depthFirstSearch(v);
        }
        order.addFirst(u);
    }
    
    private int floodFill(int u) {
        int count = 1;
        visited[u] = true;
        for (int v : transposedList.get(u)) {
            if (!visited[v]) count += floodFill(v);
        }
        return count;
    }
    
    void solve() {
        order.clear();
        visited = new boolean[nodeCount];
        Arrays.fill(visited, false);
        for (int i = 0; i < nodeCount; i++) depthFirstSearch(i);
        Arrays.fill(visited, false);
        int largeComponents = 0, smallComponents = 0;
        for (int u : order) {
            if (!visited[u]) {
                int count = floodFill(u);
                if (count >= 4) largeComponents++;
                else smallComponents += count;
            }
        }
        System.out.printf("%d %d\n", largeComponents, smallComponents);
    }
}

class ProblemSolver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GraphSolver graphSolver = new GraphSolver(scanner);
        int cases = scanner.nextInt();
        for (int i = 1; i <= cases; i++) {
            System.out.printf("Case#%d\n", i);
            graphSolver.readGraph();
            graphSolver.solve();
        }
    }
}