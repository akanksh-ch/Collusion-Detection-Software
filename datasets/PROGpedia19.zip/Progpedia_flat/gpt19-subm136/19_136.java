import java.util.*;

class ImprovedGraph {
    private static final int MAX_DIM = 1000;
    List<List<Integer>> adjacencyList = new ArrayList<>();
    int[] color, parent, discoveryTime, finishingTime;
    int time;

    public ImprovedGraph() {
        for (int i = 0; i < MAX_DIM; i++) {
            adjacencyList.add(new LinkedList<>());
        }
        color = new int[MAX_DIM];
        parent = new int[MAX_DIM];
        discoveryTime = new int[MAX_DIM];
        finishingTime = new int[MAX_DIM];
    }

    public ImprovedGraph getTranspose() {
        ImprovedGraph transpose = new ImprovedGraph();
        for (int i = 0; i < this.adjacencyList.size(); i++) {
            for (Integer vertex : this.adjacencyList.get(i)) {
                transpose.adjacencyList.get(vertex).add(i);
            }
        }
        return transpose;
    }

    public void performDFS(List<Integer> startVertices, List<Integer> resultList) {
        Arrays.fill(color, 0);
        Arrays.fill(parent, -1);
        Arrays.fill(discoveryTime, -1);
        Arrays.fill(finishingTime, -1);
        time = 0;

        for (Integer vertex : startVertices) {
            if (color[vertex] == 0) {
                dfsVisit(vertex, resultList);
            }
        }
    }

    private void dfsVisit(int vertex, List<Integer> resultList) {
        color[vertex] = 1;
        discoveryTime[vertex] = ++time;
        for (Integer adjacent : adjacencyList.get(vertex)) {
            if (color[adjacent] == 0) {
                parent[adjacent] = vertex;
                dfsVisit(adjacent, resultList);
            }
        }
        color[vertex] = 2;
        finishingTime[vertex] = ++time;
        resultList.add(0, vertex);
    }

    public List<List<Integer>> buildForest() {
        List<List<Integer>> forest = new ArrayList<>();
        for (int i = 0; i < parent.length; i++) {
            if (parent[i] == -1 && !adjacencyList.get(i).isEmpty()) { // Check for non-empty and no parent
                List<Integer> tree = new LinkedList<>();
                buildTree(i, tree);
                forest.add(tree);
            }
        }
        return forest;
    }

    private void buildTree(int root, List<Integer> tree) {
        Queue<Integer> queue = filterVerticesByValue(parent, root);
        tree.add(root);
        while (!queue.isEmpty()) {
            int child = queue.poll();
            buildTree(child, tree);
        }
    }

    private Queue<Integer> filterVerticesByValue(int[] array, int value) {
        Queue<Integer> queue = new PriorityQueue<>();
        for (int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                queue.add(i);
            }
        }
        return queue;
    }
}

class SociologyStudy {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int testCases = scanner.nextInt();
        for (int t = 0; t < testCases; t++) {
            List<Integer> initialVertices = new ArrayList<>();
            List<Integer> finishList = new ArrayList<>();
            ImprovedGraph graph = new ImprovedGraph();
            int numStudents = scanner.nextInt();
            for (int j = 0; j < numStudents; j++) {
                initialVertices.add(j);
            }
            for (int j = 0; j < numStudents; j++) {
                int student = scanner.nextInt();
                int numFriends = scanner.nextInt();
                for (int k = 0; k < numFriends; k++) {
                    graph.adjacencyList.get(student - 1).add(scanner.nextInt() - 1);
                }
            }
            graph.performDFS(initialVertices, finishList);

            ImprovedGraph transposedGraph = graph.getTranspose();
            initialVertices = new ArrayList<>();
            transposedGraph.performDFS(finishList, initialVertices);

            List<List<Integer>> groups = transposedGraph.buildForest();
            int count = 0;
            int numGroups = 0;
            int numOutsiders = 0;
            System.out.printf("Case #%d\n", t + 1);
            for (List<Integer> group : groups) {
                int groupSize = group.size();
                if (groupSize >= 4) {
                    numGroups++;
                } else {
                    numOutsiders += groupSize;
                }
            }
            System.out.printf("%d %d\n", numGroups, numOutsiders);
        }
    }
}