import java.io.*;
import java.util.Scanner;

class MatrixAnalyzer {

    private static void resetArray(boolean[] array) {
        for (int i = 0; i < array.length; i++) {
            array[i] = false;
        }
    }

    private static void resetArray(int[] array) {
        for (int i = 0; i < array.length; i++) {
            array[i] = 0;
        }
    }

    private static void populateRelationCount(boolean[][] matrix, int[] relationCount) {
        for (int rowIndex = 0; rowIndex < matrix.length; rowIndex++) {
            for (int colIndex = 0; colIndex < matrix.length; colIndex++) {
                if (matrix[rowIndex][colIndex]) {
                    relationCount[rowIndex]++;
                }
            }
        }
    }

    private static void printRelationCount(int[] rcMatrix) {
        for (int relationCount : rcMatrix) {
            System.out.print("[" + relationCount + "]");
        }
        System.out.println();
    }

    private static void transformMatrix(boolean[][] matrix) {
        final int size = matrix.length;
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (matrix[row][col]) {
                    for (int target = 0; target < size; target++) {
                        matrix[row][target] |= matrix[col][target];
                        matrix[target][col] |= matrix[target][row];
                    }
                }
            }
        }
    }

    private static void initializeMatrix(boolean[][] matrix) {
        for (int row = 0; row < matrix.length; row++) {
            java.util.Arrays.fill(matrix[row], false);
            matrix[row][row] = true;
        }
    }

    private static void printMatrix(boolean[][] matrix) {
        System.out.print("|||");
        for (int col = 1; col <= matrix.length; col++) {
            System.out.print("|" + col + "|");
        }
        System.out.println();

        for (int row = 0; row < matrix.length; row++) {
            System.out.print("|" + (row + 1) + "|");
            for (int col = 0; col < matrix.length; col++) {
                System.out.print("[" + (matrix[row][col] ? 1 : 0) + "]");
            }
            System.out.println();
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nSituations = scanner.nextInt();

        for (int s = 1; s <= nSituations; s++) {
            int matrixDim = scanner.nextInt();
            boolean[][] matrix = new boolean[matrixDim][matrixDim];
            initializeMatrix(matrix);

            for (int i = 0; i < matrixDim; i++) {
                int index = scanner.nextInt() - 1;
                int relations = scanner.nextInt();
                for (int j = 0; j < relations; j++) {
                    matrix[index][scanner.nextInt() - 1] = true;
                }
            }

            transformMatrix(matrix);
            int[] relationCount = new int[matrixDim];
            boolean[] checkedMatrix = new boolean[matrixDim];
            resetArray(relationCount);
            resetArray(checkedMatrix);
            populateRelationCount(matrix, relationCount);

            int nGroups = 0;
            int nOutliers = 0;
            for (int i = 0; i < matrixDim; i++) {
                if (checkedMatrix[i]) continue;
                int count = relationCount[i];
                int elements = 1;
                checkedMatrix[i] = true;

                for (int j = i + 1; j < matrixDim; j++) {
                    if (!checkedMatrix[j] && count == relationCount[j] && java.util.Arrays.equals(matrix[i], matrix[j])) {
                        elements++;
                        checkedMatrix[j] = true;
                    }
                }

                if (elements < 4) nOutliers += elements;
                else nGroups++;
            }

            System.out.printf("Caso #%d%n%d %d%n", s, nGroups, nOutliers);
        }
    }
}