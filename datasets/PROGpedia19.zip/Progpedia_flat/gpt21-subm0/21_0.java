import java.util.*;

class OptimizedSolution {
    private Scanner scanner;
    private int numberOfNodes;
    private int groupSizeCount;
    private boolean[] visitedNodes;
    private Deque<Integer> processingOrder = new LinkedList<>();
    private Map<Integer, Integer> nodeIndexMap = new HashMap<>();
    private List<List<Integer>> graph = new ArrayList<>();
    private List<List<Integer>> transposeGraph = new ArrayList<>();

    OptimizedSolution(Scanner scanner) {
        this.scanner = scanner;
    }

    private int addOrGetNodeIndex(int originalNode) {
        return nodeIndexMap.computeIfAbsent(originalNode, k -> {
            graph.add(new LinkedList<>());
            transposeGraph.add(new LinkedList<>());
            return nodeIndexMap.size();
        });
    }

    public void loadGraph() {
        numberOfNodes = scanner.nextInt();
        clearGraphData();
        for (int i = 0; i < numberOfNodes; i++) {
            int node = addOrGetNodeIndex(scanner.nextInt());
            int connectionsCount = scanner.nextInt();
            for (int j = 0; j < connectionsCount; j++) {
                int connectedNode = addOrGetNodeIndex(scanner.nextInt());
                graph.get(node).add(connectedNode);
                transposeGraph.get(connectedNode).add(node);
            }
        }
        numberOfNodes = nodeIndexMap.size();
    }

    private void clearGraphData() {
        nodeIndexMap.clear();
        graph.clear();
        transposeGraph.clear();
    }

    private void depthFirstSearch(int nodeIndex) {
        if (visitedNodes[nodeIndex]) return;
        visitedNodes[nodeIndex] = true;
        graph.get(nodeIndex).forEach(this::depthFirstSearch);
        processingOrder.addFirst(nodeIndex);
    }

    private void transposedDepthFirstSearch(int nodeIndex) {
        groupSizeCount++;
        visitedNodes[nodeIndex] = true;
        transposeGraph.get(nodeIndex).forEach(this::transposedDepthFirstSearch);
    }

    public void processGraphComponents() {
        processingOrder.clear();
        visitedNodes = new boolean[numberOfNodes];
        Arrays.fill(visitedNodes, false);
        for (int i = 0; i < numberOfNodes; i++) depthFirstSearch(i);
        Arrays.fill(visitedNodes, false);
        int largeGroups = 0, singleNodesCount = 0;
        for (int currentIndex : processingOrder) {
            if (!visitedNodes[currentIndex]) {
                groupSizeCount = 0;
                transposedDepthFirstSearch(currentIndex);
                if (groupSizeCount >= 4) {
                    largeGroups++;
                } else {
                    singleNodesCount += groupSizeCount;
                }
            }
        }
        System.out.printf("%d %d\n", largeGroups, singleNodesCount);
    }
}

class GraphProblemSolver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        OptimizedSolution optimizedSolution = new OptimizedSolution(scanner);
        int testCases = scanner.nextInt();
        for (int testCase = 1; testCase <= testCases; testCase++) {
            System.out.printf("Case#%d\n", testCase);
            optimizedSolution.loadGraph();
            optimizedSolution.processGraphComponents();
        }
    }
}