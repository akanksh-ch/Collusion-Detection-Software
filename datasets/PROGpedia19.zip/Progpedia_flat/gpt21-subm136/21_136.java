import java.util.*;

class SocialGraph {
    public final int MAX_SIZE = 1000;
    List<Integer>[] connections;
    int[] state, ancestor, discovery, finish;
    int clock;

    @SuppressWarnings("unchecked")
    public SocialGraph() {
        connections = new List[MAX_SIZE];
        state = new int[MAX_SIZE];
        ancestor = new int[MAX_SIZE];
        discovery = new int[MAX_SIZE];
        finish = new int[MAX_SIZE];
        for (int i = 0; i < MAX_SIZE; i++) {
            connections[i] = new LinkedList<>();
        }
    }

    public SocialGraph reverse() {
        SocialGraph reverseGraph = new SocialGraph();
        for (int i = 0; i < connections.length; i++) {
            for (Integer neighbor : connections[i]) {
                reverseGraph.connections[neighbor].add(i);
            }
        }
        return reverseGraph;
    }

    public void DFS(List<Integer> order, LinkedList<Integer> outputList) {
        Arrays.fill(state, 0);
        Arrays.fill(ancestor, -1);
        Arrays.fill(discovery, -1);
        Arrays.fill(finish, -1);
        clock = 0;
        for (Integer node : order) {
            if (state[node] == 0) visit(node, outputList);
        }
    }

    private void visit(int node, LinkedList<Integer> stack) {
        state[node] = 1;
        discovery[node] = ++clock;
        for (Integer neighbor : connections[node]) {
            if (state[neighbor] == 0) {
                ancestor[neighbor] = node;
                visit(neighbor, stack);
            }
        }
        state[node] = 2;
        finish[node] = ++clock;
        stack.addFirst(node);
    }

    @SuppressWarnings("unchecked")
    List<Integer>[] constructForests() {
        List<Integer>[] forests = new List[MAX_SIZE];
        for (int i = 0; i < MAX_SIZE; i++) {
            forests[i] = new LinkedList<>();
        }
        for (int i = 0; i < connections.length; i++) {
            if (ancestor[i] == -1) {
                createForest(i, forests[i]);
            }
        }
        return forests;
    }

    private void createForest(int root, List<Integer> forest) {
        Queue<Integer> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            int current = queue.poll();
            forest.add(current);
            for (int adj : connections[current]) {
                if (ancestor[adj] == current) queue.add(adj);
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();
        for (int scenario = 1; scenario <= scenarios; scenario++) {
            SocialGraph graph = new SocialGraph();
            LinkedList<Integer> order = new LinkedList<>();
            LinkedList<Integer> reversedOrder = new LinkedList<>();
            int students = scanner.nextInt();
            for (int i = 0; i < students; i++) {
                order.add(i);
                int student = scanner.nextInt();
                int numFriends = scanner.nextInt();
                for (int j = 0; j < numFriends; j++) {
                    graph.connections[student - 1].add(scanner.nextInt() - 1);
                }
            }

            graph.DFS(order, reversedOrder);
            SocialGraph transposedGraph = graph.reverse();
            LinkedList<Integer> postOrder = new LinkedList<>();
            transposedGraph.DFS(reversedOrder, postOrder);
            List<Integer>[] groupForests = transposedGraph.constructForests();

            int totalGroups = 0;
            int outliers = 0;
            for (List<Integer> forest : groupForests) {
                if (forest.isEmpty()) continue;
                if (forest.size() >= 4) {
                    totalGroups++;
                } else {
                    outliers += forest.size();
                }
            }
            
            System.out.printf("Case #%d: %d %d\n", scenario, totalGroups, outliers);
        }
    }
}