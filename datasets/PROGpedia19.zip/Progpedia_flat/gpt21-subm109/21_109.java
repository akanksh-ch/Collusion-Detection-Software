import java.io.*;
import java.util.*;

class SocialAnalysis {
    static void analyzeScenarios(int scenario, int studentCount, Student[] students) {
        Grupos.output.println("\n\n\nScenario " + scenario);
        for (int s = 0; s < studentCount; s++) {
            int friendCount = students[s].getFriendCount();
            if (friendCount > 0) {
                Grupos.output.print("\n\n Student: " + (s + 1) + " has " + friendCount + " friend(s): ");
                for (int f = 0; f < friendCount; f++)
                    Grupos.output.print("\n\t" + (students[s].getFriend(f) + 1));
            } else
                Grupos.output.print("\n\n Student: " + (s + 1) + " has no friends.");
        }
        Grupos.output.print("\n\n");
        if (Grupos.output.checkError())
            Grupos.output.println("An output error occurred!");
    }
    static void displayGroups(int scenario, GroupList list) {
        for (Group current = list.getFirst(); current != null; current = current.getNext())
            printGroup(current.getMembers());
        Grupos.output.println("\n\nScenario: " + scenario);
    }
    static void printGroup(DynamicStack stack) {
        int[] members = stack.extractMembers();
        Grupos.output.print("\n\n\t Group:");
        if (members.length > 0) {
            for (int member : members)
                Grupos.output.print("\n\t\t" + (member + 1));
        } else
            Grupos.output.println("\n\tEmpty");
        Grupos.output.print("\n\n");
    }
}

class Student {
    private int friendCount;
    private int[] friends;
    
    Student(int count, int[] frnds) {
        this.friendCount = count;
        this.friends = frnds;
    }
    int getFriendCount() {
        return this.friendCount;
    }
    int getFriend(int index) {
        return this.friends[index];
    }
}

class AnalysisResults {
    ExecResult first, last;
    
    void addResult(ExecResult result) {
        if (this.first == null) {
            this.first = this.last = result;
        } else {
            this.last.setNext(result);
            this.last = result;
        }
    }
    ExecResult getFirst() {
        return this.first;
    }
}

class ExecResult {
    int id;
    int groupOfFour;
    int others;
    ExecResult next;
    
    ExecResult(int id, int groups, int otherElements) {
        this.id = id;
        this.groupOfFour = groups;
        this.others = otherElements;
    }
    
    void setNext(ExecResult nxt) {
        this.next = nxt;
    }
}

class GroupList {
    private Group first, last;
    
    void addGroup(DynamicStack members) {
        Group newGroup = new Group(members);
        if (this.first == null) {
            this.first = this.last = newGroup;
        } else {
            this.last.setNext(newGroup);
            this.last = newGroup;
        }
    }
    Group getFirst() {
        return this.first;
    }
}

class Group {
    DynamicStack members;
    Group next;
    
    Group(DynamicStack mem) {
        this.members = mem;
    }
    void setNext(Group n) {
        this.next = n;
    }
    DynamicStack getMembers() {
        return this.members;
    }
    Group getNext() {
        return this.next;
    }
}

class DynamicStack {
    private int count;
    private StackNode top;
    
    int getCount() {
        return this.count;
    }
    void push(int value) {
        StackNode newNode = new StackNode(value);
        newNode.setNext(this.top);
        this.top = newNode;
        this.count++;
    }
   
    int[] extractMembers() {
        int[] elements = new int[this.count];
        StackNode current = this.top;
        int idx = 0;
        while (current != null) {
            elements[idx++] = current.getValue();
            current = current.getNext();
        }
        return elements;
    }
}

class StackNode {
    private int value;
    private StackNode next;
    
    StackNode(int val) {
        this.value = val;
    }
    void setNext(StackNode nxt) {
        this.next = nxt;
    }
    int getValue() {
        return this.value;
    }
    StackNode getNext() {
        return this.next;
    }
}

class Grupos {
    public static PrintWriter output = new PrintWriter(System.out, true);
    
    public static void main(String[] args) {
        processInput();
    }
    private static void processInput() {
        Scanner scanner = new Scanner(System.in);
        int scenarios = scanner.nextInt();
        for (int s = 1; s <= scenarios; s++) {
            int totalStudents = scanner.nextInt();
            Student[] students = new Student[totalStudents];
            for (int i = 0; i < totalStudents; i++) {
                int id = scanner.nextInt();
                int friendCount = scanner.nextInt();
                int[] friends = new int[friendCount];
                for (int j = 0; j < friendCount; j++) {
                    friends[j] = scanner.nextInt() - 1;
                }
                students[id - 1] = new Student(friendCount, friends);
            }
            SocialAnalysis.analyzeScenarios(s, totalStudents, students);
        }
    }
}