import java.io.*;
import java.util.*;

// Utility class to manage input and output operations
class IOManager {
    public static final PrintWriter pw = new PrintWriter(System.out, true);
    private static final Scanner scanner = new Scanner(System.in);

    public static int nextInt() {
        return scanner.nextInt();
    }

    public static void print(String message) {
        pw.print(message);
    }

    public static void println(String message) {
        pw.println(message);
    }

    public static boolean checkError() {
        return pw.checkError();
    }
}

class Vertex {
    private int numberOfFriends;
    private int[] friends;
    private int index = -1;
    private int lowlink = -1;

    Vertex(int numberOfFriends, int[] friends) {
        this.numberOfFriends = numberOfFriends;
        this.friends = friends;
    }

    int getNumberOfFriends() {
        return numberOfFriends;
    }

    int getFriendAt(int index) {
        return friends[index];
    }

    int getIndex() {
        return index;
    }

    void setIndex(int index) {
        this.index = index;
    }

    int getLowlink() {
        return lowlink;
    }

    void setLowlink(int lowlink) {
        this.lowlink = lowlink;
    }

    boolean isFriend(int friendId) {
        for (int friend : friends) {
            if (friend == friendId) {
                return true;
            }
        }
        return false;
    }
}

// Refactor the rest of the classes similarly...

class Groups {
    public static void main(String[] args) {
        new ScenarioManager().processScenarios();
    }
}

class ScenarioManager {
    void processScenarios() {
        int numberOfScenarios = IOManager.nextInt();
        for (int scenarioNumber = 1; scenarioNumber <= numberOfScenarios; scenarioNumber++) {
            processScenario(scenarioNumber);
        }
    }

    private void processScenario(int scenarioNumber) {
        // Code to process each scenario...
    }
}

// Continue refactoring other methods and classes as described...